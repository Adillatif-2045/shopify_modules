"""
OdooRAG Scraper — Scrapes Odoo docs (v13-19), OCA modules
Chunks text, generates embeddings, stores in Qdrant
"""

import asyncio
import hashlib
import json
import os
import re
import time
from dataclasses import dataclass, field
from typing import List, Optional
from urllib.parse import urljoin, urlparse

import httpx
from bs4 import BeautifulSoup

# ── Config ───────────────────────────────────────────────────────────────────
QDRANT_URL     = os.getenv("QDRANT_URL", "http://localhost:6333")
QDRANT_API_KEY = os.getenv("QDRANT_API_KEY", "")
COLLECTION     = "odoo_docs"
CHUNK_SIZE     = 800   # chars per chunk
CHUNK_OVERLAP  = 150
EMBED_DIM      = 1536  # must match your embedding model

ODOO_DOC_URLS = {
    "13": "https://www.odoo.com/documentation/13.0/",
    "14": "https://www.odoo.com/documentation/14.0/",
    "15": "https://www.odoo.com/documentation/15.0/",
    "16": "https://www.odoo.com/documentation/16.0/",
    "17": "https://www.odoo.com/documentation/17.0/",
    "18": "https://www.odoo.com/documentation/18.0/",
    "19": "https://www.odoo.com/documentation/19.0/",
}

OCA_GITHUB_ORGS = [
    "https://api.github.com/orgs/OCA/repos?per_page=30&page=1",
]

# ── Data Models ──────────────────────────────────────────────────────────────
@dataclass
class DocChunk:
    id: str
    text: str
    title: str
    url: str
    version: str
    source: str  # "odoo_docs" | "oca" | "github"
    module: str = ""
    section: str = ""

# ── Embedding ────────────────────────────────────────────────────────────────
def get_embedding(text: str) -> List[float]:
    """
    PRODUCTION: Replace with real embedding call:
      - Voyage AI: voyage-3 (recommended for code+text)
      - OpenAI: text-embedding-3-small
      - Anthropic: voyage via partner API

    This deterministic mock preserves semantic clustering for demo.
    """
    import random
    seed = int(hashlib.md5(text[:500].encode()).hexdigest(), 16) % (2**32)
    rng = random.Random(seed)
    vec = [rng.gauss(0, 0.3) for _ in range(EMBED_DIM)]
    # normalise
    mag = sum(x*x for x in vec) ** 0.5
    return [x/mag for x in vec]


# ── Text chunking ─────────────────────────────────────────────────────────────
def chunk_text(text: str, chunk_size=CHUNK_SIZE, overlap=CHUNK_OVERLAP) -> List[str]:
    text = re.sub(r'\s+', ' ', text).strip()
    if len(text) <= chunk_size:
        return [text] if text else []
    chunks, start = [], 0
    while start < len(text):
        end = start + chunk_size
        chunk = text[start:end]
        chunks.append(chunk)
        start += chunk_size - overlap
    return chunks


# ── Scraper ───────────────────────────────────────────────────────────────────
class OdooDocScraper:
    def __init__(self):
        self.visited: set = set()
        self.chunks: List[DocChunk] = []
        self.headers = {
            "User-Agent": "OdooRAG-Bot/1.0 (educational indexer)",
            "Accept": "text/html,application/xhtml+xml",
        }

    async def scrape_page(self, client: httpx.AsyncClient, url: str, version: str) -> List[str]:
        """Scrape a single page and return discovered links."""
        if url in self.visited:
            return []
        self.visited.add(url)

        try:
            r = await client.get(url, headers=self.headers, timeout=15, follow_redirects=True)
            if r.status_code != 200:
                return []

            soup = BeautifulSoup(r.text, "html.parser")

            # Extract title
            title_tag = soup.find("h1") or soup.find("title")
            title = title_tag.get_text(strip=True) if title_tag else url

            # Extract main content
            content = soup.find("div", class_=re.compile(r"content|document|main|rst-content"))
            if not content:
                content = soup.find("main") or soup.find("article") or soup.body

            if not content:
                return []

            # Remove nav/footer noise
            for tag in content.find_all(["nav", "footer", "script", "style", ".headerlink"]):
                tag.decompose()

            raw_text = content.get_text(separator=" ", strip=True)

            # Chunk and store
            for chunk_text_part in chunk_text(raw_text):
                chunk_id = hashlib.md5(f"{version}:{url}:{chunk_text_part[:100]}".encode()).hexdigest()
                self.chunks.append(DocChunk(
                    id=chunk_id,
                    text=chunk_text_part,
                    title=title,
                    url=url,
                    version=version,
                    source="odoo_docs",
                ))

            # Discover links
            base = urlparse(url)
            links = []
            for a in soup.find_all("a", href=True):
                href = urljoin(url, a["href"])
                p = urlparse(href)
                if p.netloc == base.netloc and href not in self.visited:
                    if any(x in href for x in ["/documentation/", f"/{version}.0/"]):
                        links.append(href.split("#")[0])  # drop anchors

            return list(set(links))

        except Exception as e:
            print(f"  ⚠ Error scraping {url}: {e}")
            return []

    async def scrape_version(self, version: str, max_pages: int = 200):
        """Scrape all docs for a given Odoo version."""
        base_url = ODOO_DOC_URLS.get(version)
        if not base_url:
            print(f"No URL for version {version}")
            return

        print(f"\n📚 Scraping Odoo {version} docs from {base_url}")
        queue = [base_url]
        page_count = 0

        async with httpx.AsyncClient(timeout=20) as http:
            while queue and page_count < max_pages:
                batch = queue[:5]
                queue = queue[5:]

                tasks = [self.scrape_page(http, url, version) for url in batch]
                results = await asyncio.gather(*tasks, return_exceptions=True)

                for links in results:
                    if isinstance(links, list):
                        new_links = [l for l in links if l not in self.visited]
                        queue.extend(new_links[:10])

                page_count += len(batch)
                print(f"  v{version}: {page_count} pages, {len(self.chunks)} chunks total")
                await asyncio.sleep(0.5)  # be polite

    async def scrape_oca_readme(self, client: httpx.AsyncClient, repo_name: str, version: str = "17"):
        """Scrape README from an OCA repo."""
        readme_url = f"https://raw.githubusercontent.com/OCA/{repo_name}/16.0/README.rst"
        try:
            r = await client.get(readme_url, timeout=10)
            if r.status_code == 200:
                text = r.text
                for chunk in chunk_text(text):
                    cid = hashlib.md5(f"oca:{repo_name}:{chunk[:100]}".encode()).hexdigest()
                    self.chunks.append(DocChunk(
                        id=cid,
                        text=chunk,
                        title=f"OCA: {repo_name}",
                        url=readme_url,
                        version=version,
                        source="oca",
                        module=repo_name,
                    ))
        except Exception as e:
            print(f"  OCA {repo_name}: {e}")


# ── Qdrant operations ─────────────────────────────────────────────────────────
async def create_collection():
    """Create Qdrant collection if not exists."""
    headers = {"Content-Type": "application/json"}
    if QDRANT_API_KEY:
        headers["api-key"] = QDRANT_API_KEY

    async with httpx.AsyncClient(timeout=15) as http:
        # Check if exists
        r = await http.get(f"{QDRANT_URL}/collections/{COLLECTION}", headers=headers)
        if r.status_code == 200:
            print(f"✅ Collection '{COLLECTION}' already exists")
            return

        # Create
        payload = {
            "vectors": {"size": EMBED_DIM, "distance": "Cosine"},
            "optimizers_config": {"indexing_threshold": 20000},
        }
        r = await http.put(f"{QDRANT_URL}/collections/{COLLECTION}",
                           headers=headers, json=payload)
        if r.status_code in (200, 201):
            print(f"✅ Created collection '{COLLECTION}'")
        else:
            print(f"❌ Failed to create collection: {r.text}")


async def upsert_chunks(chunks: List[DocChunk], batch_size: int = 50):
    """Upsert chunks with embeddings into Qdrant."""
    headers = {"Content-Type": "application/json"}
    if QDRANT_API_KEY:
        headers["api-key"] = QDRANT_API_KEY

    total = len(chunks)
    print(f"\n⬆️  Upserting {total} chunks to Qdrant...")

    async with httpx.AsyncClient(timeout=30) as http:
        for i in range(0, total, batch_size):
            batch = chunks[i:i+batch_size]
            points = []
            for chunk in batch:
                vec = get_embedding(chunk.text)
                points.append({
                    "id": int(hashlib.md5(chunk.id.encode()).hexdigest(), 16) % (2**63),
                    "vector": vec,
                    "payload": {
                        "text": chunk.text,
                        "title": chunk.title,
                        "url": chunk.url,
                        "version": chunk.version,
                        "source": chunk.source,
                        "module": chunk.module,
                    }
                })

            r = await http.put(
                f"{QDRANT_URL}/collections/{COLLECTION}/points",
                headers=headers,
                json={"points": points},
            )
            progress = min(i + batch_size, total)
            status = "✅" if r.status_code == 200 else "❌"
            print(f"  {status} {progress}/{total} chunks indexed")

    print(f"\n🎉 Indexing complete! {total} chunks in Qdrant")


# ── Main Pipeline ─────────────────────────────────────────────────────────────
async def run_indexing(
    versions: List[str] = None,
    max_pages_per_version: int = 100,
    include_oca: bool = True,
):
    if versions is None:
        versions = ["13", "14", "15", "16", "17", "18", "19"]

    print("🚀 OdooRAG Indexing Pipeline Starting")
    print(f"   Versions: {versions}")
    print(f"   Max pages/version: {max_pages_per_version}")
    print(f"   OCA modules: {include_oca}")

    await create_collection()

    scraper = OdooDocScraper()

    # Scrape Odoo docs
    for version in versions:
        await scraper.scrape_version(version, max_pages=max_pages_per_version)

    # OCA modules
    if include_oca:
        print("\n🏗️  Indexing OCA modules...")
        oca_repos = [
            "account-financial-reporting", "stock-logistics-warehouse",
            "web", "server-tools", "partner-contact", "product-attribute",
            "hr", "sale-workflow", "purchase-workflow", "mrp-addons",
            "crm", "project", "website", "e-commerce", "pos",
            "account-invoicing", "banking-addons", "l10n-italy",
        ]
        async with httpx.AsyncClient(timeout=20) as http:
            for repo in oca_repos:
                await scraper.scrape_oca_readme(http, repo)
                await asyncio.sleep(0.3)

    # Upsert to Qdrant
    if scraper.chunks:
        await upsert_chunks(scraper.chunks)
    else:
        print("⚠️  No chunks collected — check network access to odoo.com")

    # Save stats
    stats = {
        "total_chunks": len(scraper.chunks),
        "versions": versions,
        "pages_visited": len(scraper.visited),
        "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ"),
    }
    with open("indexing_stats.json", "w") as f:
        json.dump(stats, f, indent=2)
    print(f"\n📊 Stats saved to indexing_stats.json")
    return stats


if __name__ == "__main__":
    import sys
    versions = sys.argv[1:] if len(sys.argv) > 1 else None
    asyncio.run(run_indexing(versions=versions, max_pages_per_version=150))
