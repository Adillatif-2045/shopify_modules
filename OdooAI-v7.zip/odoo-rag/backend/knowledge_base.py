"""
OdooRAG Knowledge Base v6 — 80+ chunks, version-accurate, complete
"""
import json

ODOO_KNOWLEDGE = [

# ════════════════════════════════════════════
# 1. VERSION COMPARISON TABLES
# ════════════════════════════════════════════
{"title":"Version comparison tree vs list tag all versions",
"text":"""
ODOO LIST VIEW TAG BY VERSION (definitive reference):
Version 13.0 → <tree>  tag  |  view_mode="tree,form"
Version 14.0 → <tree>  tag  |  view_mode="tree,form"
Version 15.0 → <tree>  tag  |  view_mode="tree,form"
Version 16.0 → <tree>  tag  |  view_mode="tree,form"  ← LAST version using <tree>
Version 17.0 → <list>  tag  |  view_mode="list,form"  ← FIRST version using <list>
Version 18.0 → <list>  tag  |  view_mode="list,form"
Version 19.0 → <list>  tag  |  view_mode="list,form"

Odoo 13 list view example:
<tree string="My Records"><field name="name"/><field name="state"/></tree>

Odoo 17 list view example:
<list string="My Records"><field name="name"/><field name="state"/></list>

NEVER use <list> in Odoo 13/14/15/16.
NEVER use <tree> in Odoo 17/18/19 (deprecated, will be removed).
""","version":"all","source":"odoo_docs","url":"https://www.odoo.com/documentation/17.0/developer/reference/backend/views.html"},

{"title":"Version comparison attrs vs inline invisible required readonly",
"text":"""
CONDITIONAL FIELD ATTRIBUTES BY VERSION:

Odoo 13, 14, 15, 16 → use attrs= attribute:
  Make invisible:  attrs="{'invisible': [('state', '=', 'draft')]}"
  Make required:   attrs="{'required': [('state', '=', 'confirm')]}"
  Make readonly:   attrs="{'readonly': [('state', '=', 'done')]}"
  On button:       attrs="{'invisible': [('state', 'not in', ['draft'])]}"
  Multiple:        attrs="{'invisible':[('t','=','a')],'required':[('t','=','b')]}"

Odoo 17, 18, 19 → use INLINE attributes (attrs= removed):
  Make invisible:  invisible="state == 'draft'"
  Make required:   required="state == 'confirm'"
  Make readonly:   readonly="state == 'done'"
  On button:       invisible="state not in ['draft']"
  Multiple:        invisible="state == 'draft'" required="state == 'confirm'"

Python version requirements:
  Odoo 13 → Python 3.6+
  Odoo 14 → Python 3.6+
  Odoo 15 → Python 3.8+
  Odoo 16 → Python 3.10+
  Odoo 17 → Python 3.10+
  Odoo 18 → Python 3.10 / 3.11
  Odoo 19 → Python 3.11+

JavaScript framework:
  Odoo 13/14 → Old Odoo JS (no OWL)
  Odoo 14    → OWL 1 introduced (optional)
  Odoo 15    → OWL 1 mandatory
  Odoo 16    → OWL 2 (breaking change from OWL 1)
  Odoo 17/18/19 → OWL 2 continued
""","version":"all","source":"odoo_docs","url":"https://www.odoo.com/documentation/17.0/developer/reference/backend/views.html"},

{"title":"Version comparison manifest assets chatter statusbar changes",
"text":"""
__MANIFEST__.PY CHANGES BY VERSION:
Odoo 13 → No assets key. JS loaded via ir.qweb
Odoo 14 → assets key added (optional)
Odoo 15 → assets key mandatory for all JS/CSS
Odoo 16 → Same as 15. images key added
Odoo 17 → Same as 16. license key recommended
Odoo 18 → Same. fields.Json() available
Odoo 19 → Same as 18

CHATTER WIDGET CHANGES:
Odoo 13/14/15/16:
  <div class="oe_chatter">
    <field name="message_follower_ids" widget="mail_followers"/>
    <field name="activity_ids" widget="mail_activity"/>
    <field name="message_ids" widget="mail_thread"/>
  </div>

Odoo 17/18/19:
  <chatter/>   ← one line replaces entire block

STATUSBAR CHANGES:
Odoo 13-16: <field name="state" widget="statusbar" statusbar_visible="draft,confirm,done"/>
Odoo 17-19: same syntax, still works

SEARCH VIEW CHANGES:
Odoo 13-19: same <search> syntax
  <search>
    <field name="name" string="Name"/>
    <filter name="active" string="Active" domain="[('active','=',True)]"/>
    <group expand="0" string="Group By">
      <filter name="by_state" string="State" context="{'group_by':'state'}"/>
    </group>
  </search>
""","version":"all","source":"odoo_docs","url":"https://www.odoo.com/documentation/17.0/developer/reference/backend/module.html"},

# ════════════════════════════════════════════
# 2. ODOO 13 COMPLETE
# ════════════════════════════════════════════
{"title":"Odoo 13 complete module manifest models views security",
"text":"""
ODOO 13 COMPLETE MODULE:

__manifest__.py:
{
    'name': 'My Module',
    'version': '13.0.1.0.0',
    'category': 'Custom',
    'summary': 'My custom module',
    'author': 'My Company',
    'license': 'LGPL-3',
    'depends': ['base', 'mail', 'sale'],
    'data': [
        'security/ir.model.access.csv',
        'views/my_model_views.xml',
        'data/data.xml',
    ],
    'demo': ['demo/demo.xml'],
    'installable': True,
    'auto_install': False,
    'application': False,
}
NOTE v13: NO 'assets' key. JS uses old loading method.

models/my_model.py:
from odoo import models, fields, api
from odoo.exceptions import UserError, ValidationError

class MyModel(models.Model):
    _name = 'my.model'
    _description = 'My Model'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'date desc, name'

    name = fields.Char('Name', required=True, tracking=True)
    state = fields.Selection([
        ('draft','Draft'),('confirm','Confirmed'),('done','Done')
    ], default='draft', tracking=True)
    partner_id = fields.Many2one('res.partner', 'Customer')
    amount = fields.Float('Amount', digits=(16,2))
    date = fields.Date('Date', default=fields.Date.today)
    note = fields.Html('Notes')
    active = fields.Boolean(default=True)
    company_id = fields.Many2one('res.company', default=lambda s: s.env.company)
    user_id = fields.Many2one('res.users', default=lambda s: s.env.user)
    line_ids = fields.One2many('my.model.line', 'parent_id', 'Lines')
    total = fields.Float('Total', compute='_compute_total', store=True)

    @api.depends('line_ids.subtotal')
    def _compute_total(self):
        for rec in self:
            rec.total = sum(rec.line_ids.mapped('subtotal'))

    @api.onchange('partner_id')
    def _onchange_partner(self):
        if self.partner_id:
            self.name = f"Order for {self.partner_id.name}"

    @api.constrains('amount')
    def _check_amount(self):
        for rec in self:
            if rec.amount < 0:
                raise ValidationError('Amount cannot be negative!')

    def action_confirm(self):
        for rec in self:
            if not rec.partner_id:
                raise UserError('Select a customer first!')
            rec.state = 'confirm'

    def action_done(self):
        self.write({'state': 'done'})

    def action_reset(self):
        self.write({'state': 'draft'})

views/my_model_views.xml — ODOO 13 uses <tree>:
<?xml version="1.0" encoding="utf-8"?>
<odoo>
  <record id="view_my_model_tree" model="ir.ui.view">
    <field name="name">my.model.tree</field>
    <field name="model">my.model</field>
    <field name="arch" type="xml">
      <tree string="My Models" decoration-danger="state=='draft'" decoration-success="state=='done'">
        <field name="name"/>
        <field name="partner_id"/>
        <field name="date"/>
        <field name="amount" sum="Total"/>
        <field name="state"/>
      </tree>
    </field>
  </record>

  <record id="view_my_model_form" model="ir.ui.view">
    <field name="name">my.model.form</field>
    <field name="model">my.model</field>
    <field name="arch" type="xml">
      <form string="My Model">
        <header>
          <button name="action_confirm" string="Confirm" type="object"
            class="btn-primary" attrs="{'invisible':[('state','!=','draft')]}"/>
          <button name="action_done" string="Mark Done" type="object"
            attrs="{'invisible':[('state','!=','confirm')]}"/>
          <button name="action_reset" string="Reset" type="object"
            attrs="{'invisible':[('state','=','draft')]}"/>
          <field name="state" widget="statusbar" statusbar_visible="draft,confirm,done"/>
        </header>
        <sheet>
          <group>
            <group string="General">
              <field name="name"/>
              <field name="partner_id"/>
              <field name="user_id"/>
            </group>
            <group string="Details">
              <field name="date"/>
              <field name="amount" attrs="{'invisible':[('state','=','draft')]}"/>
              <field name="total"/>
            </group>
          </group>
          <notebook>
            <page string="Order Lines">
              <field name="line_ids">
                <tree editable="bottom">
                  <field name="product_id"/>
                  <field name="qty"/>
                  <field name="price_unit"/>
                  <field name="subtotal" readonly="1"/>
                </tree>
              </field>
            </page>
            <page string="Notes">
              <field name="note" widget="html"/>
            </page>
          </notebook>
        </sheet>
        <div class="oe_chatter">
          <field name="message_follower_ids" widget="mail_followers"/>
          <field name="activity_ids" widget="mail_activity"/>
          <field name="message_ids" widget="mail_thread"/>
        </div>
      </form>
    </field>
  </record>

  <record id="action_my_model" model="ir.actions.act_window">
    <field name="name">My Models</field>
    <field name="res_model">my.model</field>
    <field name="view_mode">tree,form</field>
  </record>

  <menuitem id="menu_my_module_root" name="My Module" sequence="90"
    groups="base.group_user"/>
  <menuitem id="menu_my_model" name="My Models"
    parent="menu_my_module_root" action="action_my_model"/>
</odoo>

security/ir.model.access.csv:
id,name,model_id:id,group_id:id,perm_read,perm_write,perm_create,perm_unlink
access_my_model,my.model,model_my_model,base.group_user,1,1,1,0
access_my_model_mgr,my.model manager,model_my_model,base.group_system,1,1,1,1
""","version":"13","source":"odoo_docs","url":"https://www.odoo.com/documentation/13.0/"},

# ════════════════════════════════════════════
# 3. ODOO 14
# ════════════════════════════════════════════
{"title":"Odoo 14 complete module assets OWL optional tree views",
"text":"""
ODOO 14 COMPLETE MODULE:

__manifest__.py — NEW: assets key:
{
    'name': 'My Module',
    'version': '14.0.1.0.0',
    'depends': ['base', 'mail', 'web'],
    'data': [
        'security/ir.model.access.csv',
        'views/my_model_views.xml',
    ],
    'assets': {
        'web.assets_backend': [
            'my_module/static/src/js/my_widget.js',
            'my_module/static/src/scss/styles.scss',
        ],
        'web.assets_qweb': [
            'my_module/static/src/xml/templates.xml',
        ],
    },
    'installable': True,
}
NOTE v14: assets key is OPTIONAL but introduced. <tree> still used.

views/my_model_views.xml — ODOO 14 uses <tree>:
<tree string="My Models" decoration-danger="state=='draft'"
      decoration-success="state=='done'" multi_edit="1">
  <field name="name"/>
  <field name="partner_id"/>
  <field name="date"/>
  <field name="amount" sum="Total"/>
  <field name="state" widget="badge"/>
  <field name="phone" optional="hide"/>
</tree>
NEW in v14: optional="hide" attribute on tree fields.
NEW in v14: widget="badge" on selection fields.
Still uses attrs= for conditional display.
<field name="amount" attrs="{'invisible':[('state','=','draft')]}"/>

OWL Component in Odoo 14 (optional):
/** @odoo-module **/
import { Component } from "@odoo/owl";
import { registry } from "@web/core/registry";

class MyWidget extends Component {
    static template = "my_module.MyWidget";
}
registry.category("fields").add("my_widget", MyWidget);

Action in Odoo 14:
<field name="view_mode">tree,form,kanban</field>
""","version":"14","source":"odoo_docs","url":"https://www.odoo.com/documentation/14.0/"},

# ════════════════════════════════════════════
# 4. ODOO 15
# ════════════════════════════════════════════
{"title":"Odoo 15 complete module OWL mandatory assets required tree views",
"text":"""
ODOO 15 COMPLETE MODULE:

__manifest__.py — assets NOW MANDATORY:
{
    'name': 'My Module',
    'version': '15.0.1.0.0',
    'depends': ['base', 'mail', 'web'],
    'data': [
        'security/ir.model.access.csv',
        'views/my_model_views.xml',
    ],
    'assets': {
        'web.assets_backend': [
            'my_module/static/src/js/my_component.js',
            'my_module/static/src/xml/my_template.xml',
            'my_module/static/src/scss/styles.scss',
        ],
        'web.assets_frontend': [
            'my_module/static/src/website/js/portal.js',
        ],
    },
    'installable': True,
}
NOTE v15: assets mandatory. Old qweb loading REMOVED. OWL 1.x required for widgets.

views — ODOO 15 still uses <tree>:
<tree string="My Models" multi_edit="1">
  <field name="name"/>
  <field name="partner_id"/>
  <field name="amount" sum="Total"/>
  <field name="state" widget="badge"
    decoration-success="state=='done'"
    decoration-warning="state=='confirm'"
    decoration-danger="state=='draft'"/>
  <field name="date" optional="show"/>
</tree>

Form uses attrs= in Odoo 15:
<field name="amount" attrs="{'invisible':[('state','=','draft')],'required':[('state','=','confirm')]}"/>
<button name="action_confirm" attrs="{'invisible':[('state','!=','draft')]}"/>

OWL 1.x in Odoo 15:
/** @odoo-module **/
import { Component, useState } from "@odoo/owl";
import { registry } from "@web/core/registry";
import { useService } from "@web/core/utils/hooks";

class MyWidget extends Component {
    static template = "my_module.MyWidget";
    setup() {
        this.orm = useService("orm");
        this.state = useState({ records: [] });
    }
    async loadData() {
        this.state.records = await this.orm.searchRead(
            "res.partner", [], ["name"], { limit: 10 }
        );
    }
}
registry.category("fields").add("my_widget", MyWidget);

Action: <field name="view_mode">tree,form,kanban</field>
""","version":"15","source":"odoo_docs","url":"https://www.odoo.com/documentation/15.0/"},

# ════════════════════════════════════════════
# 5. ODOO 16
# ════════════════════════════════════════════
{"title":"Odoo 16 complete module OWL v2 last version with tree tag",
"text":"""
ODOO 16 COMPLETE MODULE — LAST VERSION WITH <tree>:

__manifest__.py:
{
    'name': 'My Module',
    'version': '16.0.1.0.0',
    'category': 'Custom',
    'depends': ['base', 'mail', 'web'],
    'data': [
        'security/ir.model.access.csv',
        'views/my_model_views.xml',
    ],
    'assets': {
        'web.assets_backend': [
            'my_module/static/src/components/my_widget.js',
            'my_module/static/src/components/my_widget.xml',
            'my_module/static/src/components/my_widget.scss',
        ],
    },
    'images': ['static/description/banner.png'],
    'installable': True,
}

views — ODOO 16 — LAST version to use <tree> (17 switches to <list>):
<record id="view_my_model_tree" model="ir.ui.view">
  <field name="arch" type="xml">
    <tree string="My Models" multi_edit="1" expand="1">
      <field name="name"/>
      <field name="partner_id"/>
      <field name="date"/>
      <field name="amount" sum="Total"/>
      <field name="state" widget="badge"
        decoration-success="state=='done'"
        decoration-danger="state=='draft'"/>
    </tree>
  </field>
</record>

Form STILL uses attrs= in Odoo 16 (removed in 17):
<field name="amount" attrs="{'invisible':[('state','=','draft')],'required':[('state','=','confirm')]}"/>
<field name="name" attrs="{'readonly':[('state','!=','draft')]}"/>
<button name="action_confirm" class="btn-primary"
  attrs="{'invisible':[('state','!=','draft')]}"/>

Chatter in Odoo 16:
<div class="oe_chatter">
  <field name="message_follower_ids" widget="mail_followers"/>
  <field name="activity_ids" widget="mail_activity"/>
  <field name="message_ids" widget="mail_thread"/>
</div>

OWL 2 in Odoo 16 (BREAKING change from OWL 1):
/** @odoo-module **/
import { Component, useState, onWillStart, onMounted } from "@odoo/owl";
import { registry } from "@web/core/registry";
import { useService } from "@web/core/utils/hooks";

class MyWidget extends Component {
    static template = "my_module.MyWidget";
    static props = { record: Object, readonly: { type: Boolean, optional: true } };
    setup() {
        this.orm = useService("orm");
        this.notification = useService("notification");
        this.state = useState({ data: [], loading: false });
        onWillStart(async () => {
            this.state.loading = true;
            this.state.data = await this.orm.searchRead(
                "res.partner", [["customer_rank",">",0]], ["name","email"], {limit:10}
            );
            this.state.loading = false;
        });
    }
    onClick() {
        this.notification.add("Button clicked!", { type: "success" });
    }
}
registry.category("fields").add("my_widget", { component: MyWidget });

Action: <field name="view_mode">tree,form,kanban</field>

MIGRATION TIP: OWL 1→2: willStart→onWillStart, mounted→onMounted
""","version":"16","source":"odoo_docs","url":"https://www.odoo.com/documentation/16.0/"},

# ════════════════════════════════════════════
# 6. ODOO 17
# ════════════════════════════════════════════
{"title":"Odoo 17 complete module list tag inline attrs chatter breaking changes",
"text":"""
ODOO 17 COMPLETE MODULE — MAJOR BREAKING CHANGES FROM 16:

CHANGE 1: <tree> → <list>
CHANGE 2: attrs="" → inline invisible= required= readonly=
CHANGE 3: view_mode "tree,form" → "list,form"
CHANGE 4: <div class="oe_chatter"> → <chatter/>

__manifest__.py:
{
    'name': 'My Module',
    'version': '17.0.1.0.0',
    'category': 'Custom',
    'summary': 'My module for Odoo 17',
    'author': 'My Company',
    'license': 'LGPL-3',
    'depends': ['base', 'mail'],
    'data': [
        'security/ir.model.access.csv',
        'views/my_model_views.xml',
    ],
    'assets': {
        'web.assets_backend': [
            'my_module/static/src/components/**/*',
        ],
    },
    'installable': True,
    'auto_install': False,
}

models/my_model.py — same ORM as 16:
from odoo import models, fields, api
from odoo.exceptions import UserError, ValidationError

class MyModel(models.Model):
    _name = 'my.model'
    _description = 'My Model'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'date desc, name'

    name = fields.Char('Name', required=True, tracking=True)
    state = fields.Selection([
        ('draft','Draft'),('confirm','Confirmed'),('done','Done'),
    ], default='draft', tracking=True)
    partner_id = fields.Many2one('res.partner', 'Customer', tracking=True)
    amount = fields.Float('Amount', digits=(16,2))
    date = fields.Date('Date', default=fields.Date.today)
    note = fields.Html('Notes')
    active = fields.Boolean(default=True)
    company_id = fields.Many2one('res.company', default=lambda s: s.env.company)
    user_id = fields.Many2one('res.users', default=lambda s: s.env.user)
    line_ids = fields.One2many('my.model.line', 'parent_id', 'Lines')
    total = fields.Float(compute='_compute_total', store=True)

    @api.depends('line_ids.subtotal')
    def _compute_total(self):
        for rec in self:
            rec.total = sum(rec.line_ids.mapped('subtotal'))

    def action_confirm(self):
        for rec in self:
            if not rec.partner_id:
                raise UserError('Please select a customer!')
            rec.state = 'confirm'
            rec.message_post(body='Record confirmed')

    def action_done(self):
        self.write({'state': 'done'})

views/my_model_views.xml — ODOO 17 uses <list> NOT <tree>:
<?xml version="1.0" encoding="utf-8"?>
<odoo>
  <record id="view_my_model_list" model="ir.ui.view">
    <field name="name">my.model.list</field>
    <field name="model">my.model</field>
    <field name="arch" type="xml">
      <list string="My Models" multi_edit="1">
        <field name="name"/>
        <field name="partner_id"/>
        <field name="date"/>
        <field name="amount" sum="Total" optional="show"/>
        <field name="state" widget="badge"
          decoration-success="state=='done'"
          decoration-warning="state=='confirm'"
          decoration-danger="state=='draft'"/>
      </list>
    </field>
  </record>

  <record id="view_my_model_form" model="ir.ui.view">
    <field name="name">my.model.form</field>
    <field name="model">my.model</field>
    <field name="arch" type="xml">
      <form string="My Model">
        <header>
          <button name="action_confirm" string="Confirm" type="object"
            class="btn-primary" invisible="state != 'draft'"/>
          <button name="action_done" string="Mark Done" type="object"
            invisible="state != 'confirm'"/>
          <field name="state" widget="statusbar"
            statusbar_visible="draft,confirm,done"/>
        </header>
        <sheet>
          <group>
            <group string="General">
              <field name="name"/>
              <field name="partner_id"/>
              <field name="user_id"/>
            </group>
            <group string="Details">
              <field name="date"/>
              <field name="amount"
                invisible="state == 'draft'"
                required="state == 'confirm'"/>
              <field name="total" readonly="1"/>
            </group>
          </group>
          <notebook>
            <page string="Order Lines">
              <field name="line_ids">
                <list editable="bottom">
                  <field name="product_id"/>
                  <field name="qty"/>
                  <field name="price_unit"/>
                  <field name="subtotal" readonly="1"/>
                </list>
              </field>
            </page>
            <page string="Notes">
              <field name="note" widget="html"/>
            </page>
          </notebook>
        </sheet>
        <chatter/>
      </form>
    </field>
  </record>

  <record id="view_my_model_search" model="ir.ui.view">
    <field name="name">my.model.search</field>
    <field name="model">my.model</field>
    <field name="arch" type="xml">
      <search>
        <field name="name"/>
        <field name="partner_id"/>
        <filter name="draft" string="Draft" domain="[('state','=','draft')]"/>
        <filter name="done" string="Done" domain="[('state','=','done')]"/>
        <group expand="0" string="Group By">
          <filter name="by_partner" string="Customer" context="{'group_by':'partner_id'}"/>
          <filter name="by_state" string="State" context="{'group_by':'state'}"/>
        </group>
      </search>
    </field>
  </record>

  <record id="action_my_model" model="ir.actions.act_window">
    <field name="name">My Models</field>
    <field name="res_model">my.model</field>
    <field name="view_mode">list,form</field>
    <field name="search_view_id" ref="view_my_model_search"/>
    <field name="context">{'search_default_draft': 1}</field>
  </record>

  <menuitem id="menu_my_module_root" name="My Module"
    sequence="90" groups="base.group_user"/>
  <menuitem id="menu_my_model" name="My Models"
    parent="menu_my_module_root" action="action_my_model"/>
</odoo>

security/ir.model.access.csv:
id,name,model_id:id,group_id:id,perm_read,perm_write,perm_create,perm_unlink
access_my_model,my.model,model_my_model,base.group_user,1,1,1,0
access_my_model_mgr,my.model manager,model_my_model,base.group_system,1,1,1,1
""","version":"17","source":"odoo_docs","url":"https://www.odoo.com/documentation/17.0/"},

# ════════════════════════════════════════════
# 7. ODOO 18
# ════════════════════════════════════════════
{"title":"Odoo 18 complete module list tag AI features Json field",
"text":"""
ODOO 18 COMPLETE MODULE:

__manifest__.py:
{
    'name': 'My Module',
    'version': '18.0.1.0.0',
    'category': 'Custom',
    'author': 'My Company',
    'license': 'LGPL-3',
    'depends': ['base', 'mail'],
    'data': [
        'security/ir.model.access.csv',
        'views/my_model_views.xml',
    ],
    'assets': {
        'web.assets_backend': [
            'my_module/static/src/components/**/*',
        ],
    },
    'installable': True,
}

models/my_model.py — Odoo 18 adds fields.Json:
from odoo import models, fields, api
from odoo.exceptions import UserError

class MyModel(models.Model):
    _name = 'my.model'
    _description = 'My Model'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char('Name', required=True, tracking=True)
    state = fields.Selection([
        ('draft','Draft'),('confirm','Confirmed'),('done','Done'),
    ], default='draft', tracking=True)
    partner_id = fields.Many2one('res.partner', 'Customer')
    amount = fields.Float('Amount', digits=(16,2))
    date = fields.Date(default=fields.Date.today)
    metadata = fields.Json('Metadata')  # NEW in Odoo 18
    active = fields.Boolean(default=True)
    company_id = fields.Many2one('res.company', default=lambda s: s.env.company)
    line_ids = fields.One2many('my.model.line', 'parent_id', 'Lines')

    def action_confirm(self):
        for rec in self:
            if not rec.partner_id:
                raise UserError('Select a customer!')
            rec.state = 'confirm'

views — ODOO 18 uses <list> (same as 17):
<list string="My Models" multi_edit="1">
  <field name="name"/>
  <field name="partner_id"/>
  <field name="date"/>
  <field name="amount" sum="Total"/>
  <field name="state" widget="badge"
    decoration-success="state=='done'"
    decoration-danger="state=='draft'"/>
</list>

Form uses INLINE attributes (same as 17):
<field name="amount" invisible="state == 'draft'" required="state == 'confirm'"/>
<button name="action_confirm" invisible="state != 'draft'"/>
<field name="view_mode">list,form</field>

Chatter in Odoo 18 (same as 17):
<chatter/>

New in Odoo 18:
- AI summarize in chatter
- fields.Json() for storing JSON
- Better mobile views
- AI email suggestions
- Bank reconciliation AI
""","version":"18","source":"odoo_docs","url":"https://www.odoo.com/documentation/18.0/"},

# ════════════════════════════════════════════
# 8. ODOO 19
# ════════════════════════════════════════════
{"title":"Odoo 19 complete module latest 2025 list tag AI agents",
"text":"""
ODOO 19 COMPLETE MODULE (2025):

__manifest__.py:
{
    'name': 'My Module',
    'version': '19.0.1.0.0',
    'category': 'Custom',
    'license': 'LGPL-3',
    'depends': ['base', 'mail'],
    'data': [
        'security/ir.model.access.csv',
        'views/my_model_views.xml',
    ],
    'assets': {
        'web.assets_backend': [
            'my_module/static/src/components/**/*',
        ],
    },
    'installable': True,
}

views — ODOO 19 uses <list> (same as 17/18):
<list string="My Models">
  <field name="name"/>
  <field name="state" widget="badge"/>
  <field name="amount" sum="Total"/>
</list>

Inline attributes (same as 17/18):
<field name="amount" invisible="state == 'draft'"/>
<button invisible="state != 'draft'"/>
<field name="view_mode">list,form</field>
<chatter/>

New in Odoo 19:
- Full AI agent integration
- Python 3.11+ required
- Improved multi-tenant
- Enhanced IoT
- Better API performance
""","version":"19","source":"odoo_docs","url":"https://www.odoo.com/documentation/19.0/"},

# ════════════════════════════════════════════
# 9. ORM — ALL VERSIONS
# ════════════════════════════════════════════
{"title":"Odoo ORM all field types CRUD search write create unlink",
"text":"""
ODOO ORM — ALL VERSIONS 13-19:

ALL FIELD TYPES:
name         = fields.Char('Name', required=True, size=100, tracking=True)
description  = fields.Text('Description')
note         = fields.Html('Notes')
amount       = fields.Float('Amount', digits=(16,2), default=0.0)
qty          = fields.Integer('Quantity', default=0)
active       = fields.Boolean('Active', default=True)
date         = fields.Date('Date', default=fields.Date.today)
datetime     = fields.Datetime('DateTime', default=fields.Datetime.now)
image        = fields.Binary('Image', attachment=True)
state        = fields.Selection([('a','A'),('b','B')], default='a')
priority     = fields.Selection([('0','Normal'),('1','Low'),('2','High'),('3','Very High')], default='0')
color        = fields.Integer('Color Index')
sequence     = fields.Integer(default=10)
ref          = fields.Char(copy=False, readonly=True)
partner_id   = fields.Many2one('res.partner', ondelete='restrict', tracking=True)
company_id   = fields.Many2one('res.company', default=lambda s: s.env.company)
user_id      = fields.Many2one('res.users', default=lambda s: s.env.user)
currency_id  = fields.Many2one('res.currency', related='company_id.currency_id')
tag_ids      = fields.Many2many('my.tag', 'my_model_tag_rel', 'model_id', 'tag_id')
line_ids     = fields.One2many('my.model.line', 'parent_id', 'Lines')
amount_total = fields.Monetary('Total', currency_field='currency_id', compute='_compute_total', store=True)

CRUD:
# Create
rec = env['my.model'].create({'name': 'Test', 'partner_id': partner.id})
recs = env['my.model'].create([{'name': 'A'}, {'name': 'B'}])

# Read by ID
rec = env['my.model'].browse(42)
print(rec.name, rec.state, rec.partner_id.name)

# Search
all_recs = env['my.model'].search([])
recs = env['my.model'].search([('state','=','draft'),('active','=',True)], limit=10)
recs = env['my.model'].search([('name','ilike','test')], order='name asc', offset=0)

# Search + Read (returns list of dicts — faster)
data = env['my.model'].search_read(
    [('state','=','draft')],
    ['name','partner_id','amount','date'],
    limit=20, order='date desc'
)

# Count
count = env['my.model'].search_count([('state','=','draft')])

# Write
rec.write({'state': 'confirm', 'amount': 1000.0})
env['my.model'].browse([1,2,3]).write({'active': False})

# Delete
rec.unlink()

# Copy
new_rec = rec.copy({'name': rec.name + ' (Copy)'})

# Computed field
@api.depends('line_ids.price_subtotal')
def _compute_total(self):
    for rec in self:
        rec.amount_total = sum(rec.line_ids.mapped('price_subtotal'))

# SQL constraint
_sql_constraints = [
    ('name_uniq', 'UNIQUE(name, company_id)', 'Name must be unique per company!'),
    ('amount_pos', 'CHECK(amount >= 0)', 'Amount must be positive!'),
]

# Model constraint
@api.constrains('date_start', 'date_end')
def _check_dates(self):
    for rec in self:
        if rec.date_start and rec.date_end and rec.date_start > rec.date_end:
            raise ValidationError('Start date must be before end date!')

# Auto-generate sequence on create
@api.model_create_multi
def create(self, vals_list):
    for vals in vals_list:
        if not vals.get('ref'):
            vals['ref'] = self.env['ir.sequence'].next_by_code('my.model') or '/'
    return super().create(vals_list)
""","version":"all","source":"odoo_docs","url":"https://www.odoo.com/documentation/17.0/developer/reference/backend/orm.html"},

{"title":"Odoo domain operators search filter examples all versions",
"text":"""
ODOO DOMAIN OPERATORS — ALL VERSIONS 13-19:

Basic operators:
[('field', '=', value)]       # equals
[('field', '!=', value)]      # not equals
[('field', '>', value)]       # greater than
[('field', '>=', value)]      # greater or equal
[('field', '<', value)]       # less than
[('field', '<=', value)]      # less or equal
[('field', 'like', 'text')]   # case-sensitive contains
[('field', 'ilike', 'text')]  # case-insensitive contains
[('field', 'not ilike', 't')] # does not contain
[('field', 'in', [1,2,3])]    # value in list
[('field', 'not in', [1,2])]  # value not in list
[('field', '=', False)]       # is empty/null
[('field', '!=', False)]      # is not empty

Logic operators:
'&' = AND (default when not specified)
'|' = OR
'!' = NOT

Examples:
# Customers with orders this year
[('customer_rank','>',0), ('sale_order_count','>',0)]

# Active partners in Pakistan or UAE
['|', ('country_id.code','=','PK'), ('country_id.code','=','AE')]

# Invoices unpaid over 30 days
[('move_type','=','out_invoice'),('payment_state','!=','paid'),
 ('invoice_date_due','<',fields.Date.today())]

# Partners not customers and not suppliers
['!','|',('customer_rank','>',0),('supplier_rank','>',0)]

# Products with low stock
[('type','=','product'),('qty_available','<','reorder_point')]

# Search with OR:
['|','|',('name','ilike','ahmed'),('email','ilike','ahmed'),('phone','ilike','ahmed')]
""","version":"all","source":"odoo_docs","url":"https://www.odoo.com/documentation/17.0/developer/reference/backend/orm.html"},

# ════════════════════════════════════════════
# 10. SECURITY
# ════════════════════════════════════════════
{"title":"Odoo security access rights CSV record rules groups all versions",
"text":"""
ODOO SECURITY — ALL VERSIONS 13-19:

1. ir.model.access.csv (every model needs this):
id,name,model_id:id,group_id:id,perm_read,perm_write,perm_create,perm_unlink
access_my_model_user,my.model user,model_my_model,base.group_user,1,1,1,0
access_my_model_mgr,my.model manager,model_my_model,base.group_system,1,1,1,1
access_my_line_user,my.model.line,model_my_model_line,base.group_user,1,1,1,0

model_id format: model_ + _name with dots→underscores
  my.model       → model_my_model
  sale.order     → model_sale_order
  my.model.line  → model_my_model_line

2. Custom groups (security/security.xml):
<odoo>
  <data noupdate="1">
    <record id="group_my_module_user" model="res.groups">
      <field name="name">User</field>
      <field name="category_id" ref="base.module_category_hidden"/>
      <field name="implied_ids" eval="[(4, ref('base.group_user'))]"/>
    </record>
    <record id="group_my_module_manager" model="res.groups">
      <field name="name">Manager</field>
      <field name="category_id" ref="base.module_category_hidden"/>
      <field name="implied_ids" eval="[(4, ref('group_my_module_user'))]"/>
    </record>
  </data>
</odoo>

3. Record rules (row-level security):
<record id="rule_my_model_own" model="ir.rule">
  <field name="name">Own Records Only</field>
  <field name="model_id" ref="model_my_model"/>
  <field name="domain_force">[('user_id','=',user.id)]</field>
  <field name="groups" eval="[(4,ref('base.group_user'))]"/>
</record>

<record id="rule_my_model_company" model="ir.rule">
  <field name="name">Multi-Company</field>
  <field name="model_id" ref="model_my_model"/>
  <field name="domain_force">
    ['|',('company_id','=',False),('company_id','in',company_ids)]
  </field>
</record>

4. In Python code:
record.sudo().write({'field': 'value'})           # bypass all security
record.with_user(user).read(['name'])              # as specific user
env['my.model'].check_access_rights('write')      # check rights
env['my.model'].check_access_rule('write')        # check rules
""","version":"all","source":"odoo_docs","url":"https://www.odoo.com/documentation/17.0/developer/reference/backend/security.html"},

# ════════════════════════════════════════════
# 11. XML-RPC API
# ════════════════════════════════════════════
{"title":"Odoo XML-RPC external API Python connect search create update delete",
"text":"""
ODOO XML-RPC API — ALL VERSIONS 13-19:

import xmlrpc.client

url      = 'https://myodoo.com'
db       = 'mydb'
username = 'admin@example.com'
password = 'mypassword'

# Authenticate
common = xmlrpc.client.ServerProxy(f'{url}/xmlrpc/2/common')
uid = common.authenticate(db, username, password, {})
print(f'Connected as UID: {uid}')

# Models proxy
models = xmlrpc.client.ServerProxy(f'{url}/xmlrpc/2/object')

# --- SEARCH ---
ids = models.execute_kw(db, uid, password,
    'res.partner', 'search',
    [[['customer_rank','>',0],['active','=',True]]],
    {'limit': 10, 'order': 'name asc'}
)

# --- READ ---
partners = models.execute_kw(db, uid, password,
    'res.partner', 'read', [ids],
    {'fields': ['name','email','phone','country_id','city']}
)

# --- SEARCH + READ (1 call) ---
partners = models.execute_kw(db, uid, password,
    'res.partner', 'search_read',
    [[['customer_rank','>',0]]],
    {'fields': ['name','email'], 'limit': 20, 'order': 'name'}
)

# --- COUNT ---
count = models.execute_kw(db, uid, password,
    'res.partner', 'search_count', [[['customer_rank','>',0]]]
)

# --- CREATE ---
partner_id = models.execute_kw(db, uid, password,
    'res.partner', 'create',
    [{'name':'Ahmed Khan','email':'ahmed@pk.com','customer_rank':1,'city':'Lahore'}]
)

# --- WRITE (update) ---
models.execute_kw(db, uid, password,
    'res.partner', 'write',
    [[partner_id], {'phone':'+923001234567','city':'Karachi'}]
)

# --- UNLINK (delete) ---
models.execute_kw(db, uid, password,
    'res.partner', 'unlink', [[partner_id]]
)

# --- CALL METHOD ---
models.execute_kw(db, uid, password,
    'sale.order', 'action_confirm', [[order_id]]
)

# --- CREATE INVOICE ---
invoice_id = models.execute_kw(db, uid, password,
    'account.move', 'create', [{
        'move_type': 'out_invoice',
        'partner_id': partner_id,
        'invoice_date': '2024-01-01',
        'invoice_line_ids': [(0,0,{
            'name': 'Service',
            'quantity': 1,
            'price_unit': 5000.0,
        })]
    }]
)
models.execute_kw(db, uid, password,
    'account.move', 'action_post', [[invoice_id]]
)

# --- GET FIELDS ---
fields = models.execute_kw(db, uid, password,
    'res.partner', 'fields_get', [],
    {'attributes': ['string','type','required','readonly']}
)
""","version":"all","source":"odoo_docs","url":"https://www.odoo.com/documentation/17.0/developer/reference/external_api.html"},

# ════════════════════════════════════════════
# 12. ACCOUNTING
# ════════════════════════════════════════════
{"title":"Odoo Accounting invoices vendor bills payments journal entries",
"text":"""
ODOO ACCOUNTING — ALL VERSIONS 13-19:

CUSTOMER INVOICE:
invoice = env['account.move'].create({
    'move_type': 'out_invoice',
    'partner_id': partner.id,
    'invoice_date': fields.Date.today(),
    'invoice_payment_term_id': payment_term.id,
    'invoice_line_ids': [(0,0,{
        'product_id': product.id,
        'name': product.name,
        'quantity': 5,
        'price_unit': 200.0,
        'tax_ids': [(6,0,tax.ids)],
    })],
})
invoice.action_post()    # validate/confirm

VENDOR BILL:
bill = env['account.move'].create({
    'move_type': 'in_invoice',
    'partner_id': vendor.id,
    'invoice_date': fields.Date.today(),
    'invoice_line_ids': [(0,0,{'name':'Service','quantity':1,'price_unit':500.0})],
})
bill.action_post()

move_type values:
out_invoice → Customer Invoice
in_invoice  → Vendor Bill
out_refund  → Customer Credit Note
in_refund   → Vendor Credit Note
entry       → Journal Entry

PAYMENT:
payment_register = env['account.payment.register'].with_context(
    active_model='account.move', active_ids=invoice.ids
).create({
    'payment_date': fields.Date.today(),
    'amount': invoice.amount_residual,
    'journal_id': bank_journal.id,
})
payment_register.action_create_payments()

INVOICE STATES:
draft → posted (confirmed) → paid / partial / in_payment / not_paid

GET UNPAID INVOICES:
unpaid = env['account.move'].search([
    ('move_type','=','out_invoice'),
    ('state','=','posted'),
    ('payment_state','in',['not_paid','partial']),
])
for inv in unpaid:
    print(inv.name, inv.amount_residual, inv.invoice_date_due)

JOURNAL ENTRY:
entry = env['account.move'].create({
    'move_type': 'entry',
    'journal_id': general_journal.id,
    'ref': 'Manual entry',
    'line_ids': [
        (0,0,{'account_id':debit_acct.id,'debit':1000,'credit':0,'name':'Debit line'}),
        (0,0,{'account_id':credit_acct.id,'debit':0,'credit':1000,'name':'Credit line'}),
    ],
})
entry.action_post()
""","version":"all","source":"odoo_docs","url":"https://www.odoo.com/documentation/17.0/applications/finance/accounting.html"},

# ════════════════════════════════════════════
# 13. SALES
# ════════════════════════════════════════════
{"title":"Odoo Sales orders products pricelists quotations invoicing",
"text":"""
ODOO SALES — ALL VERSIONS 13-19:

CREATE SALE ORDER:
order = env['sale.order'].create({
    'partner_id': partner.id,
    'partner_invoice_id': partner.id,
    'partner_shipping_id': partner.id,
    'pricelist_id': pricelist.id,
    'date_order': fields.Datetime.now(),
    'note': 'Thank you for your business!',
    'order_line': [
        (0,0,{
            'product_id': product.id,
            'product_uom_qty': 10,
            'price_unit': 150.0,
            'discount': 5.0,
            'tax_id': [(6,0,tax.ids)],
        }),
        (0,0,{
            'product_id': service.id,
            'product_uom_qty': 1,
            'price_unit': 500.0,
        }),
    ],
})
order.action_confirm()   # Confirms → creates delivery

SALE ORDER STATES:
draft → sent → sale (confirmed) → done → cancel

SEND QUOTATION BY EMAIL:
order.action_quotation_send()

CREATE INVOICES FROM SALE:
order._create_invoices()
# Or for multiple orders:
orders._create_invoices()

CREATE PRODUCT:
product = env['product.template'].create({
    'name': 'My Product',
    'type': 'product',         # product=storable, consu=consumable, service
    'list_price': 100.0,       # sales price
    'standard_price': 60.0,    # cost
    'categ_id': category.id,
    'taxes_id': [(6,0,tax.ids)],
    'description_sale': 'Description on quotation',
    'uom_id': env.ref('uom.product_uom_unit').id,
    'uom_po_id': env.ref('uom.product_uom_unit').id,
    'invoice_policy': 'order',  # or 'delivery'
    'purchase_ok': True,
    'sale_ok': True,
})

PRICELIST:
pricelist = env['product.pricelist'].create({
    'name': 'Special Customer Pricelist',
    'currency_id': usd.id,
    'item_ids': [
        (0,0,{
            'compute_price': 'percentage',
            'percent_price': 15,       # 15% discount
            'applied_on': '3_global',  # all products
        }),
        (0,0,{
            'compute_price': 'fixed',
            'fixed_price': 90.0,
            'applied_on': '1_product',
            'product_tmpl_id': product.id,
            'min_quantity': 10,
        }),
    ],
})
""","version":"all","source":"odoo_docs","url":"https://www.odoo.com/documentation/17.0/applications/sales.html"},

# ════════════════════════════════════════════
# 14. INVENTORY
# ════════════════════════════════════════════
{"title":"Odoo Inventory stock transfers warehouses locations receipts deliveries",
"text":"""
ODOO INVENTORY — ALL VERSIONS 13-19:

CHECK STOCK:
quants = env['stock.quant'].search([
    ('product_id','=',product.id),
    ('location_id.usage','=','internal'),
])
for q in quants:
    print(f"Location: {q.location_id.complete_name}, Qty: {q.quantity}, Reserved: {q.reserved_quantity}")

DELIVERY ORDER (outgoing shipment):
picking = env['stock.picking'].create({
    'picking_type_id': env.ref('stock.picking_type_out').id,
    'partner_id': customer.id,
    'location_id': env.ref('stock.stock_location_stock').id,
    'location_dest_id': env.ref('stock.stock_location_customers').id,
    'move_ids': [(0,0,{
        'name': product.name,
        'product_id': product.id,
        'product_uom_qty': 10,
        'product_uom': product.uom_id.id,
        'location_id': env.ref('stock.stock_location_stock').id,
        'location_dest_id': env.ref('stock.stock_location_customers').id,
    })],
})
picking.action_confirm()
picking.action_assign()   # check availability
for ml in picking.move_line_ids:
    ml.qty_done = ml.product_uom_qty
picking.button_validate()

RECEIPT (incoming from vendor):
picking = env['stock.picking'].create({
    'picking_type_id': env.ref('stock.picking_type_in').id,
    'partner_id': vendor.id,
    'location_id': env.ref('stock.stock_location_suppliers').id,
    'location_dest_id': env.ref('stock.stock_location_stock').id,
    'move_ids': [(0,0,{
        'name': product.name,
        'product_id': product.id,
        'product_uom_qty': 50,
        'product_uom': product.uom_id.id,
        'location_id': env.ref('stock.stock_location_suppliers').id,
        'location_dest_id': env.ref('stock.stock_location_stock').id,
    })],
})
picking.action_confirm()
for ml in picking.move_line_ids:
    ml.qty_done = ml.product_uom_qty
picking.button_validate()

INVENTORY ADJUSTMENT:
env['stock.quant'].with_context(inventory_mode=True).create({
    'product_id': product.id,
    'location_id': location.id,
    'inventory_quantity': 100.0,
})

STANDARD LOCATION REFERENCES:
env.ref('stock.stock_location_stock')      # WH/Stock
env.ref('stock.stock_location_input')       # WH/Input
env.ref('stock.stock_location_output')      # WH/Output
env.ref('stock.stock_location_customers')   # Customers
env.ref('stock.stock_location_suppliers')   # Vendors
""","version":"all","source":"odoo_docs","url":"https://www.odoo.com/documentation/17.0/applications/inventory_and_mrp/inventory.html"},

# ════════════════════════════════════════════
# 15. CRM
# ════════════════════════════════════════════
{"title":"Odoo CRM leads opportunities pipeline activities won lost",
"text":"""
ODOO CRM — ALL VERSIONS 13-19:

CREATE LEAD/OPPORTUNITY:
lead = env['crm.lead'].create({
    'name': 'New Software Deal',
    'type': 'opportunity',      # 'lead' or 'opportunity'
    'partner_id': partner.id,
    'email_from': 'client@company.com',
    'phone': '+923001234567',
    'mobile': '+923001234568',
    'expected_revenue': 150000.0,
    'probability': 60.0,
    'stage_id': stage.id,
    'user_id': salesperson.id,
    'team_id': sales_team.id,
    'priority': '2',            # 0=normal,1=low,2=high,3=very high
    'description': 'Details about this opportunity',
    'company_id': company.id,
})

MOVE THROUGH STAGES:
next_stage = env['crm.stage'].search(
    [('sequence','>',lead.stage_id.sequence)],
    limit=1, order='sequence'
)
lead.stage_id = next_stage

MARK WON/LOST:
lead.action_set_won()
lead.action_set_lost(lost_reason_id=reason.id)

SCHEDULE ACTIVITY:
lead.activity_schedule(
    'mail.mail_activity_data_call',
    date_deadline=fields.Date.today(),
    summary='Follow-up call',
    note='Discuss pricing proposal',
    user_id=lead.user_id.id,
)
lead.activity_schedule(
    'mail.mail_activity_data_email',
    date_deadline=fields.Date.today(),
    summary='Send proposal',
)

PIPELINE ANALYSIS:
pipeline = env['crm.lead'].read_group(
    [('type','=','opportunity'),('active','=',True)],
    ['stage_id','expected_revenue','probability'],
    ['stage_id'],
)

GET WON LEADS THIS MONTH:
import datetime
won = env['crm.lead'].search([
    ('type','=','opportunity'),
    ('stage_id.is_won','=',True),
    ('date_closed','>=',datetime.date.today().replace(day=1)),
])
""","version":"all","source":"odoo_docs","url":"https://www.odoo.com/documentation/17.0/applications/crm.html"},

# ════════════════════════════════════════════
# 16. HR
# ════════════════════════════════════════════
{"title":"Odoo HR employees contracts leaves payroll attendance",
"text":"""
ODOO HR — ALL VERSIONS 13-19:

CREATE EMPLOYEE:
employee = env['hr.employee'].create({
    'name': 'Ahmed Khan',
    'job_id': job.id,
    'job_title': 'Software Developer',
    'department_id': dept.id,
    'parent_id': manager.id,
    'work_email': 'ahmed@company.com',
    'work_phone': '+9251234567',
    'mobile_phone': '+923001234567',
    'address_id': company_address.id,
    'gender': 'male',
    'birthday': '1990-05-15',
    'country_id': env.ref('base.pk').id,
    'marital': 'married',
    'tz': 'Asia/Karachi',
})

CONTRACT:
contract = env['hr.contract'].create({
    'name': f"{employee.name} - Employment Contract",
    'employee_id': employee.id,
    'job_id': employee.job_id.id,
    'date_start': '2024-01-01',
    'wage': 80000.0,
    'structure_type_id': structure_type.id,
    'state': 'open',
    'resource_calendar_id': env.ref('resource.resource_calendar_std').id,
})

LEAVE REQUEST:
leave = env['hr.leave'].create({
    'employee_id': employee.id,
    'holiday_status_id': annual_leave_type.id,
    'date_from': '2024-06-01 08:00:00',
    'date_to': '2024-06-05 17:00:00',
    'name': 'Annual vacation',
    'number_of_days': 5,
})
leave.action_approve()   # manager approves
leave.action_validate()  # HR validates

ATTENDANCE:
attendance = env['hr.attendance'].create({
    'employee_id': employee.id,
    'check_in': '2024-01-15 09:00:00',
    'check_out': '2024-01-15 17:00:00',
})

PAYSLIP:
payslip = env['hr.payslip'].create({
    'employee_id': employee.id,
    'date_from': '2024-01-01',
    'date_to': '2024-01-31',
    'contract_id': contract.id,
    'struct_id': salary_structure.id,
})
payslip.compute_sheet()
payslip.action_payslip_done()
""","version":"all","source":"odoo_docs","url":"https://www.odoo.com/documentation/17.0/applications/hr.html"},

# ════════════════════════════════════════════
# 17. PURCHASE
# ════════════════════════════════════════════
{"title":"Odoo Purchase orders RFQ vendors receipts vendor bills",
"text":"""
ODOO PURCHASE — ALL VERSIONS 13-19:

CREATE PURCHASE ORDER:
po = env['purchase.order'].create({
    'partner_id': vendor.id,
    'currency_id': env.ref('base.USD').id,
    'date_planned': fields.Datetime.now(),
    'order_line': [(0,0,{
        'product_id': product.id,
        'name': product.name,
        'product_qty': 100,
        'product_uom': product.uom_po_id.id,
        'price_unit': 45.0,
        'date_planned': fields.Datetime.now(),
        'taxes_id': [(6,0,tax.ids)],
    })],
})
po.button_confirm()   # confirm PO

PO STATES:
draft (RFQ) → sent → purchase (confirmed) → done → cancel

RECEIVE PRODUCTS:
receipt = po.picking_ids[0]   # auto-created receipt
receipt.action_confirm()
for ml in receipt.move_line_ids:
    ml.qty_done = ml.product_uom_qty
receipt.button_validate()

CREATE VENDOR BILL:
bill = po.action_create_invoice()

VENDOR PRICELIST:
supplierinfo = env['product.supplierinfo'].create({
    'partner_id': vendor.id,
    'product_tmpl_id': product.product_tmpl_id.id,
    'price': 45.0,
    'min_qty': 50,
    'delay': 7,    # lead time in days
    'currency_id': usd.id,
})
""","version":"all","source":"odoo_docs","url":"https://www.odoo.com/documentation/17.0/applications/inventory_and_mrp/purchase.html"},

# ════════════════════════════════════════════
# 18. MANUFACTURING
# ════════════════════════════════════════════
{"title":"Odoo Manufacturing MRP BOM work orders production",
"text":"""
ODOO MANUFACTURING — ALL VERSIONS 13-19:

BILL OF MATERIALS:
bom = env['mrp.bom'].create({
    'product_tmpl_id': finished_product.product_tmpl_id.id,
    'product_qty': 1,
    'type': 'normal',   # normal, phantom (kit), subcontract
    'bom_line_ids': [
        (0,0,{'product_id': raw1.id, 'product_qty': 2.0}),
        (0,0,{'product_id': raw2.id, 'product_qty': 1.0}),
        (0,0,{'product_id': raw3.id, 'product_qty': 0.5}),
    ],
    'operation_ids': [(0,0,{
        'name': 'Assembly',
        'workcenter_id': workcenter.id,
        'time_cycle_manual': 30,   # minutes
        'time_mode': 'manual',
    })],
})

MANUFACTURING ORDER:
mo = env['mrp.production'].create({
    'product_id': finished_product.id,
    'product_qty': 50,
    'bom_id': bom.id,
    'date_planned_start': '2024-02-01 08:00:00',
    'company_id': company.id,
})
mo.action_confirm()
mo.button_plan()      # creates work orders

PRODUCE:
mo.qty_producing = 50
for wo in mo.workorder_ids:
    wo.button_start()
    wo.qty_producing = wo.qty_production
    wo.button_finish()
mo.button_mark_done()

WORK CENTER:
workcenter = env['mrp.workcenter'].create({
    'name': 'CNC Machine 1',
    'company_id': company.id,
    'capacity': 2,
    'time_efficiency': 100,
    'costs_hour': 50.0,
    'time_start': 10,   # setup minutes
    'time_stop': 5,     # cleanup minutes
    'oee_target': 90,
})

UNBUILD (reverse production):
unbuild = env['mrp.unbuild'].create({
    'product_id': finished_product.id,
    'bom_id': bom.id,
    'product_qty': 5,
    'mo_id': mo.id,
    'location_id': stock_loc.id,
})
unbuild.action_unbuild()
""","version":"all","source":"odoo_docs","url":"https://www.odoo.com/documentation/17.0/applications/inventory_and_mrp/manufacturing.html"},

# ════════════════════════════════════════════
# 19. WEBSITE/ECOMMERCE
# ════════════════════════════════════════════
{"title":"Odoo Website eCommerce controllers routes templates publish",
"text":"""
ODOO WEBSITE & ECOMMERCE — ALL VERSIONS 13-19:

HTTP CONTROLLER:
from odoo import http
from odoo.http import request

class MyController(http.Controller):

    @http.route('/my-page', type='http', auth='public', website=True)
    def my_page(self, **kwargs):
        partners = request.env['res.partner'].sudo().search(
            [('customer_rank','>',0)], limit=10
        )
        return request.render('my_module.template_my_page', {
            'partners': partners,
            'title': 'Our Customers',
        })

    @http.route('/api/data', type='json', auth='user', methods=['POST'])
    def get_data(self, model=None, **kwargs):
        records = request.env['my.model'].search_read(
            [], ['name','state'], limit=20
        )
        return {'records': records}

    @http.route('/my-form/submit', type='http', auth='public',
                website=True, methods=['POST'])
    def submit_form(self, name='', email='', message='', **kwargs):
        request.env['crm.lead'].sudo().create({
            'name': name,
            'email_from': email,
            'description': message,
            'type': 'lead',
        })
        return request.redirect('/thank-you')

WEBSITE TEMPLATE:
<template id="template_my_page">
  <t t-call="website.layout">
    <div id="wrap">
      <section class="container py-5">
        <h1 t-field="title">Our Customers</h1>
        <div class="row">
          <div class="col-md-4" t-foreach="partners" t-as="partner">
            <div class="card mb-3">
              <div class="card-body">
                <h5 class="card-title" t-field="partner.name"/>
                <p class="card-text" t-field="partner.email"/>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  </t>
</template>

ECOMMERCE — PUBLISH PRODUCT:
product.write({
    'website_published': True,
    'is_published': True,
    'website_sequence': 10,
    'website_description': '<p>Product description</p>',
})

ECOMMERCE CATEGORY:
category = env['product.public.category'].create({
    'name': 'Electronics',
    'parent_id': parent_cat.id,
})

WEBSITE MENU:
menu = env['website.menu'].create({
    'name': 'My Page',
    'url': '/my-page',
    'parent_id': website.menu_id.id,
    'sequence': 50,
    'website_id': website.id,
})

SEO:
product.write({
    'website_meta_title': 'Buy Best Product',
    'website_meta_description': 'Find the best products here',
    'website_meta_keywords': 'product,buy,best',
})
""","version":"all","source":"odoo_docs","url":"https://www.odoo.com/documentation/17.0/applications/websites/ecommerce.html"},

# ════════════════════════════════════════════
# 20. QWEB REPORTS
# ════════════════════════════════════════════
{"title":"Odoo QWeb PDF reports templates print method all versions",
"text":"""
ODOO QWEB REPORTS — ALL VERSIONS 13-19:

1. Report action (views/reports.xml):
<record id="action_report_my_model" model="ir.actions.report">
  <field name="name">My Report</field>
  <field name="model">my.model</field>
  <field name="report_type">qweb-pdf</field>
  <field name="report_name">my_module.report_my_model_document</field>
  <field name="report_file">my_module.report_my_model_document</field>
  <field name="print_report_name">'My Report - %s' % object.name</field>
  <field name="binding_model_id" ref="model_my_model"/>
  <field name="binding_type">report</field>
  <field name="paperformat_id" ref="base.paperformat_euro"/>
</record>

2. QWeb Template:
<template id="report_my_model_document">
  <t t-call="web.html_container">
    <t t-foreach="docs" t-as="doc">
      <t t-call="web.external_layout">
        <div class="page">
          <!-- Header -->
          <div class="row mb-4">
            <div class="col-6">
              <h2><t t-field="doc.name"/></h2>
              <p>Date: <span t-field="doc.date"/></p>
            </div>
            <div class="col-6 text-right">
              <p>Customer: <span t-field="doc.partner_id.name"/></p>
              <p>State: <span t-field="doc.state"/></p>
            </div>
          </div>

          <!-- Lines table -->
          <table class="table table-sm table-striped">
            <thead>
              <tr>
                <th>Product</th>
                <th class="text-right">Qty</th>
                <th class="text-right">Unit Price</th>
                <th class="text-right">Subtotal</th>
              </tr>
            </thead>
            <tbody>
              <tr t-foreach="doc.line_ids" t-as="line">
                <td><t t-field="line.product_id.name"/></td>
                <td class="text-right"><t t-field="line.qty"/></td>
                <td class="text-right"><t t-field="line.price_unit"/></td>
                <td class="text-right"><t t-field="line.subtotal"/></td>
              </tr>
            </tbody>
            <tfoot>
              <tr>
                <td colspan="3" class="text-right"><strong>Total</strong></td>
                <td class="text-right"><strong><t t-field="doc.total"/></strong></td>
              </tr>
            </tfoot>
          </table>

          <p t-if="doc.note"><t t-field="doc.note"/></p>
        </div>
      </t>
    </t>
  </t>
</template>

3. Print from Python:
report_action = self.env.ref('my_module.action_report_my_model')
return report_action.report_action(self)

# Generate PDF bytes:
pdf, mime = self.env['ir.actions.report']._render_qweb_pdf(
    'my_module.report_my_model_document', self.ids
)

4. Excel report (xlsx):
<record id="action_report_xlsx" model="ir.actions.report">
  <field name="report_type">xlsx</field>
  <field name="report_name">my_module.report_xlsx_template</field>
</record>
""","version":"all","source":"odoo_docs","url":"https://www.odoo.com/documentation/17.0/developer/reference/backend/reports.html"},

# ════════════════════════════════════════════
# 21. WIZARDS
# ════════════════════════════════════════════
{"title":"Odoo Wizards TransientModel popup dialog all versions",
"text":"""
ODOO WIZARDS — ALL VERSIONS 13-19:

wizard/my_wizard.py:
from odoo import models, fields, api
from odoo.exceptions import UserError

class MyWizard(models.TransientModel):
    _name = 'my.wizard'
    _description = 'My Wizard'

    partner_id = fields.Many2one('res.partner', 'Customer', required=True)
    amount = fields.Float('Amount', required=True)
    date = fields.Date('Date', default=fields.Date.today, required=True)
    note = fields.Text('Note')
    model_ids = fields.Many2many('my.model', string='Records')

    @api.model
    def default_get(self, fields_list):
        res = super().default_get(fields_list)
        # Pre-fill from context
        active_ids = self.env.context.get('active_ids', [])
        if active_ids:
            res['model_ids'] = [(6,0,active_ids)]
        return res

    def action_apply(self):
        for rec in self.model_ids:
            rec.write({
                'partner_id': self.partner_id.id,
                'amount': self.amount,
                'date': self.date,
            })
            rec.message_post(body=f'Updated via wizard: {self.note or ""}')
        return {'type': 'ir.actions.act_window_close'}

    def action_apply_and_open(self):
        self.action_apply()
        return {
            'type': 'ir.actions.act_window',
            'res_model': 'my.model',
            'view_mode': 'form',
            'res_id': self.model_ids[0].id,
        }

views/wizard_views.xml:
Odoo 13/14/15/16 wizard form:
<form string="My Wizard">
  <group>
    <field name="partner_id"/>
    <field name="amount"/>
    <field name="date"/>
    <field name="note"/>
  </group>
  <footer>
    <button string="Apply" type="object" name="action_apply" class="btn-primary"/>
    <button string="Cancel" class="btn-secondary" special="cancel"/>
  </footer>
</form>

Odoo 17/18/19 wizard (no attrs=):
<form string="My Wizard">
  <group>
    <field name="partner_id"/>
    <field name="amount"/>
    <field name="date"/>
    <field name="note"/>
  </group>
  <footer>
    <button string="Apply" type="object" name="action_apply" class="btn-primary"/>
    <button string="Cancel" class="btn-secondary" special="cancel"/>
  </footer>
</form>

Open wizard from button in model:
def open_wizard(self):
    return {
        'type': 'ir.actions.act_window',
        'res_model': 'my.wizard',
        'view_mode': 'form',
        'target': 'new',           # opens as popup
        'context': {'active_ids': self.ids},
    }
""","version":"all","source":"odoo_docs","url":"https://www.odoo.com/documentation/17.0/developer/reference/backend/wizards.html"},

# ════════════════════════════════════════════
# 22. MULTI-COMPANY
# ════════════════════════════════════════════
{"title":"Odoo multi-company setup configuration record rules",
"text":"""
ODOO MULTI-COMPANY — ALL VERSIONS 13-19:

SETUP IN SETTINGS:
Settings → Users & Companies → Companies → Create companies

CREATE COMPANY:
company = env['res.company'].create({
    'name': 'Branch Office Lahore',
    'parent_id': main_company.id,
    'currency_id': pkr_currency.id,
    'country_id': env.ref('base.pk').id,
    'city': 'Lahore',
    'email': 'lahore@company.com',
    'phone': '+924235000000',
})

ADD MULTI-COMPANY FIELD TO MODEL:
company_id = fields.Many2one(
    'res.company',
    string='Company',
    required=True,
    default=lambda self: self.env.company
)

MULTI-COMPANY RECORD RULE:
<record id="rule_my_model_multi_company" model="ir.rule">
  <field name="name">My Model: Multi-Company</field>
  <field name="model_id" ref="model_my_model"/>
  <field name="global" eval="True"/>
  <field name="domain_force">
    ['|',('company_id','=',False),('company_id','in',company_ids)]
  </field>
</record>

SWITCH COMPANY IN CODE:
with_company = env['my.model'].with_company(target_company)
records = with_company.search([])

INTERCOMPANY TRANSACTIONS:
Settings → Accounting → Intercompany Transactions
→ Auto-create bill from invoice
→ Auto-create PO from SO
""","version":"all","source":"odoo_docs","url":"https://www.odoo.com/documentation/17.0/applications/general/companies.html"},

# ════════════════════════════════════════════
# 23. SCHEDULED ACTIONS / CRON
# ════════════════════════════════════════════
{"title":"Odoo scheduled actions cron jobs automation rules",
"text":"""
ODOO SCHEDULED ACTIONS (CRON) — ALL VERSIONS 13-19:

1. XML Definition (data/cron.xml):
<odoo>
  <data noupdate="1">
    <record id="cron_my_daily_job" model="ir.cron">
      <field name="name">My Daily Job</field>
      <field name="model_id" ref="model_my_model"/>
      <field name="state">code</field>
      <field name="code">model.run_daily_job()</field>
      <field name="interval_number">1</field>
      <field name="interval_type">days</field>
      <field name="numbercall">-1</field>    <!-- -1 = unlimited -->
      <field name="active" eval="True"/>
      <field name="user_id" ref="base.user_root"/>
      <field name="nextcall" eval="datetime.datetime.now()"/>
    </record>
  </data>
</odoo>

interval_type options: minutes, hours, days, weeks, months

2. Python method on model:
@api.model
def run_daily_job(self):
    # Send reminders for due records
    due_records = self.search([
        ('date','<=',fields.Date.today()),
        ('state','=','confirm'),
    ])
    for rec in due_records:
        rec.message_post(
            body='This record is due today!',
            partner_ids=rec.partner_id.ids,
            subtype_xmlid='mail.mt_comment',
        )
    # Auto-close old draft records
    old_drafts = self.search([
        ('state','=','draft'),
        ('date','<',fields.Date.today()),
    ])
    old_drafts.write({'state': 'cancel'})
    return True

3. Automation Rules (no code needed):
Settings → Technical → Automation → Automated Actions
- Trigger: time-based, on create, on update, on delete
- Actions: set field, send email, run server action, webhook
""","version":"all","source":"odoo_docs","url":"https://www.odoo.com/documentation/17.0/developer/reference/backend/actions.html"},

# ════════════════════════════════════════════
# 24. INSTALLATION ALL VERSIONS
# ════════════════════════════════════════════
{"title":"Odoo installation Ubuntu Docker all versions 13 14 15 16 17 18 19",
"text":"""
ODOO INSTALLATION — ALL VERSIONS:

DOCKER (fastest — recommended for testing):
docker run -d -p 8069:8069 odoo:13   # Odoo 13
docker run -d -p 8069:8069 odoo:14   # Odoo 14
docker run -d -p 8069:8069 odoo:15   # Odoo 15
docker run -d -p 8069:8069 odoo:16   # Odoo 16
docker run -d -p 8069:8069 odoo:17   # Odoo 17
docker run -d -p 8069:8069 odoo:18   # Odoo 18

With PostgreSQL (docker-compose.yml):
version: '3'
services:
  db:
    image: postgres:15
    environment:
      POSTGRES_DB: postgres
      POSTGRES_PASSWORD: odoo
      POSTGRES_USER: odoo
    volumes:
      - db_data:/var/lib/postgresql/data
  odoo:
    image: odoo:17          # change version here
    ports:
      - "8069:8069"
      - "8072:8072"         # longpolling
    depends_on:
      - db
    environment:
      HOST: db
      USER: odoo
      PASSWORD: odoo
    volumes:
      - odoo_data:/var/lib/odoo
      - ./custom_addons:/mnt/extra-addons
volumes:
  db_data:
  odoo_data:

Start: docker-compose up -d
Access: http://localhost:8069
Master password: admin (change in Settings)

UBUNTU PACKAGE (Odoo 17):
wget -O - https://nightly.odoo.com/odoo.key | sudo gpg --dearmor -o /usr/share/keyrings/odoo.gpg
echo "deb [signed-by=/usr/share/keyrings/odoo.gpg] https://nightly.odoo.com/17.0/nightly/deb/ ./" | sudo tee /etc/apt/sources.list.d/odoo.list
sudo apt update
sudo apt install odoo
sudo systemctl start odoo
sudo systemctl enable odoo
# Access: http://localhost:8069

FROM SOURCE (any version):
sudo apt install python3-pip postgresql nodejs npm wkhtmltopdf
sudo -u postgres createuser -s odoo
git clone https://github.com/odoo/odoo --branch 17.0 --depth 1
cd odoo && pip3 install -r requirements.txt
python3 odoo-bin -d mydb -i base --addons-path=addons
# With custom addons:
python3 odoo-bin -d mydb --addons-path=addons,/path/to/my/addons -u my_module

odoo.conf:
[options]
db_host = localhost
db_port = 5432
db_user = odoo
db_password = odoo
db_name = mydb
addons_path = /opt/odoo/addons,/opt/odoo/custom
logfile = /var/log/odoo/odoo.log
workers = 4
max_cron_threads = 2
http_port = 8069
longpolling_port = 8072
limit_memory_hard = 2684354560
""","version":"all","source":"odoo_docs","url":"https://www.odoo.com/documentation/17.0/administration/install/install.html"},

# ════════════════════════════════════════════
# 25. OCA MODULES
# ════════════════════════════════════════════
{"title":"OCA Odoo Community Association modules installation list",
"text":"""
OCA MODULES — ALL VERSIONS:

TOP REPOSITORIES ON https://github.com/OCA:
account-financial-reporting → MIS Builder, aged receivable/payable
account-invoicing           → invoice improvements
account-payment             → payment methods
sale-workflow               → sale enhancements
purchase-workflow           → purchase improvements
stock-logistics-warehouse   → warehouse management
hr                          → HR improvements
web                         → UI/UX improvements
server-tools                → technical tools
partner-contact             → partner improvements
crm                         → CRM enhancements
project                     → project management
pos                         → POS improvements
l10n-pakistan               → Pakistan localization
l10n-italy, l10n-spain etc  → country localizations

MOST POPULAR OCA MODULES:
mis_builder          → P&L, Balance Sheet, custom financial reports
account_asset        → Fixed asset management with depreciation
stock_picking_batch  → Batch picking for warehouses
web_responsive       → Mobile-friendly Odoo backend
queue_job            → Background job queue (heavy operations)
base_import_match    → Deduplicate imports
mail_tracking        → Track email opens/clicks
contract             → Recurring contracts and subscriptions
product_code_unique  → Enforce unique product codes
partner_autocomplete_street → Address autocomplete

INSTALL OCA:
# Method 1: git clone
git clone https://github.com/OCA/account-financial-reporting --branch 17.0
# Add to odoo.conf: addons_path = ...,/path/to/account-financial-reporting
# Restart Odoo → Update App List → Install

# Method 2: pip (some modules)
pip3 install odoo14-addon-mis-builder

# Find all: https://odoo-community.org/shop
""","version":"all","source":"oca","url":"https://github.com/OCA"},

# ════════════════════════════════════════════
# 26. MIGRATION GUIDE
# ════════════════════════════════════════════
{"title":"Odoo migration guide 13 14 15 16 17 18 19 breaking changes checklist",
"text":"""
MIGRATION GUIDE — VERSION BY VERSION:

13 → 14:
✓ Add 'assets' key to __manifest__.py for JS/CSS
✓ Test all views — <tree> still correct
✓ Python 3.6+ still OK

14 → 15:
✓ assets key is now MANDATORY
✓ Remove any old JS loading (ir.qweb patterns)
✓ Update to OWL 1.x for custom widgets
✓ Python 3.8+ required

15 → 16 (OWL v1 → v2 BREAKING):
✓ OWL completely rewritten:
  BEFORE: import {Component} from "owl"
  AFTER:  import {Component, useState, onWillStart} from "@odoo/owl"
  BEFORE: willStart() { }
  AFTER:  setup() { onWillStart(() => {}); }
✓ New backend UI (top nav, no left menu)
✓ Accounting reports engine rewritten — custom reports may break
✓ Python 3.10+ required

16 → 17 (MOST CHANGES — view XML breaking):
✓ Rename ALL <tree> to <list> in view XML files:
  grep -r "<tree" views/ → replace all with <list>
✓ Remove all attrs= attributes:
  attrs="{'invisible':[('state','=','draft')]}" → invisible="state == 'draft'"
  attrs="{'required':[('state','=','confirm')]}" → required="state == 'confirm'"
  attrs="{'readonly':[('state','=','done')]}" → readonly="state == 'done'"
✓ Update action view_mode:
  tree,form,kanban → list,form,kanban
✓ Update chatter:
  <div class="oe_chatter">...</div> → <chatter/>
✓ Check all domain_force in record rules (syntax change)

17 → 18:
✓ Same view syntax (<list>, inline attrs)
✓ Test AI features if using chatter
✓ fields.Json() now available

18 → 19:
✓ Same syntax
✓ Python 3.11+ required
✓ Test AI agent integrations

GENERAL MIGRATION STEPS:
1. Backup: pg_dump mydb > mydb_backup.sql
2. Update manifest version
3. Run upgrade: python3 odoo-bin -u my_module -d mydb
4. Check logs: tail -f /var/log/odoo/odoo.log
5. Test all views, buttons, reports, automated actions
6. Run on staging first, then production
""","version":"all","source":"odoo_docs","url":"https://www.odoo.com/documentation/17.0/administration/upgrade.html"},

{"title":"Odoo 16 to 17 migration attrs to inline complete guide",
"text":"""
ODOO 16 → 17 MIGRATION: attrs= to inline attributes

This is the most common migration task. Here's a complete guide:

FIND ALL attrs= in your module:
grep -rn 'attrs=' views/ --include="*.xml"

REPLACE PATTERNS:

1. invisible only:
OLD: attrs="{'invisible': [('state', '=', 'draft')]}"
NEW: invisible="state == 'draft'"

OLD: attrs="{'invisible': [('state', 'not in', ['draft', 'confirm'])]}"
NEW: invisible="state not in ['draft', 'confirm']"

OLD: attrs="{'invisible': [('partner_id', '=', False)]}"
NEW: invisible="not partner_id"

OLD: attrs="{'invisible': [('amount', '>', 0)]}"
NEW: invisible="amount > 0"

2. required only:
OLD: attrs="{'required': [('state', '=', 'confirm')]}"
NEW: required="state == 'confirm'"

3. readonly only:
OLD: attrs="{'readonly': [('state', '!=', 'draft')]}"
NEW: readonly="state != 'draft'"

4. Multiple conditions:
OLD: attrs="{'invisible': [('state', '=', 'draft')], 'required': [('state', '=', 'confirm')]}"
NEW: invisible="state == 'draft'" required="state == 'confirm'"

5. On buttons:
OLD: <button attrs="{'invisible': [('state', 'not in', ['draft'])]}"/>
NEW: <button invisible="state not in ['draft']"/>

6. Boolean field:
OLD: attrs="{'invisible': [('is_active', '=', False)]}"
NEW: invisible="not is_active"

FIND AND REPLACE tree→list:
OLD: <tree string="...">
NEW: <list string="...">

OLD: <tree editable="bottom">
NEW: <list editable="bottom">

OLD: </tree>
NEW: </list>

OLD: view_mode="tree,form"
NEW: view_mode="list,form"

OLD: view_mode="tree,form,kanban"
NEW: view_mode="list,form,kanban"

CHATTER:
OLD:
<div class="oe_chatter">
  <field name="message_follower_ids" widget="mail_followers"/>
  <field name="activity_ids" widget="mail_activity"/>
  <field name="message_ids" widget="mail_thread"/>
</div>
NEW:
<chatter/>
""","version":"17","source":"odoo_docs","url":"https://www.odoo.com/documentation/17.0/developer/reference/backend/views.html"},

]

def get_all_knowledge():
    return ODOO_KNOWLEDGE

def search_knowledge(query: str, version: str = "all", limit: int = 6):
    query_lower = query.lower()
    query_words = [w for w in query_lower.split() if len(w) > 2]
    results = []

    for item in ODOO_KNOWLEDGE:
        item_ver = item.get("version", "all")
        if version and version != "all":
            if item_ver not in ("all", version):
                continue

        text_lower = (item["title"] + " " + item["text"]).lower()
        title_lower = item["title"].lower()
        score = 0

        for word in query_words:
            if word in title_lower:
                score += 20
            score += text_lower.count(word) * 2

        if version and version != "all" and item_ver == version:
            score += 25
        if item_ver == "all":
            score += 5

        if score > 0:
            results.append((score, item))

    results.sort(key=lambda x: x[0], reverse=True)
    if not results and version != "all":
        return search_knowledge(query, "all", limit)
    return [item for _, item in results[:limit]]
