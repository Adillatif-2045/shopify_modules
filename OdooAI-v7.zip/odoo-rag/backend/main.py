"""
OdooAI Backend v7 — Fixed syntax, auto ZIP generation, live Odoo, complete dataset
"""
from fastapi import FastAPI, HTTPException, File, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse, FileResponse
from pydantic import BaseModel
from typing import Optional, List
import httpx, json, os, zipfile, uuid, io
from datetime import datetime
from pathlib import Path
from knowledge_base import search_knowledge, get_all_knowledge

app = FastAPI(title="OdooAI API", version="7.0.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True,
                   allow_methods=["*"], allow_headers=["*"])

OPENROUTER_API_KEY = os.getenv("OPENROUTER_API_KEY", "")
ANTHROPIC_API_KEY  = os.getenv("ANTHROPIC_API_KEY", "")
QDRANT_URL         = os.getenv("QDRANT_URL", "http://qdrant:6333")
QDRANT_API_KEY     = os.getenv("QDRANT_API_KEY", "")
AI_PROVIDER        = "openrouter" if OPENROUTER_API_KEY else "anthropic"
OPENROUTER_MODEL   = os.getenv("OPENROUTER_MODEL", "anthropic/claude-sonnet-4-5")

TEMP_DIR = Path("/tmp/odooai_files")
TEMP_DIR.mkdir(exist_ok=True)

active_streams: dict = {}


# ── MODELS ──────────────────────────────────────────────────────────────────
class ChatRequest(BaseModel):
    message: str
    version: Optional[str] = "all"
    odoo_url: Optional[str] = None
    odoo_db: Optional[str] = None
    odoo_user: Optional[str] = None
    odoo_password: Optional[str] = None
    conversation_history: Optional[List[dict]] = []
    enable_actions: Optional[bool] = False
    stream_id: Optional[str] = None
    file_content: Optional[str] = None
    file_name: Optional[str] = None

class OdooActionRequest(BaseModel):
    odoo_url: str
    db: str
    username: str
    password: str
    model: str = ""
    method: str = ""
    args: list = []
    kwargs: dict = {}

class StopRequest(BaseModel):
    stream_id: str

class ZipRequest(BaseModel):
    files: dict
    zip_name: str = "odooai_module.zip"


# ── SYSTEM PROMPT ────────────────────────────────────────────────────────────
def build_system_prompt(version: str, odoo_connected: bool,
                        odoo_url: str = "", odoo_db: str = "") -> str:
    # Version-specific rules
    if version and version != "all":
        try:
            ver_int = int(version)
        except:
            ver_int = 17

        if ver_int >= 17:
            list_tag    = "<list>"
            close_tag   = "</list>"
            attrs_note  = "Use INLINE attributes: invisible=\"state == 'draft'\"  required=\"state == 'confirm'\""
            view_mode   = "list,form"
            chatter_tag = "<chatter/>"
        else:
            list_tag    = "<tree>"
            close_tag   = "</tree>"
            attrs_note  = "Use attrs= attribute: attrs=\"{'invisible':[('state','=','draft')]}\""
            view_mode   = "tree,form"
            chatter_tag = '<div class="oe_chatter">...</div>'

        if ver_int >= 19:
            python_req = "Python 3.11+"
        elif ver_int >= 16:
            python_req = "Python 3.10+"
        elif ver_int >= 15:
            python_req = "Python 3.8+"
        else:
            python_req = "Python 3.6+"

        if ver_int >= 16:
            owl_note = "OWL 2 (import from @odoo/owl)"
        elif ver_int == 15:
            owl_note = "OWL 1 (mandatory)"
        elif ver_int == 14:
            owl_note = "OWL 1 (optional)"
        else:
            owl_note = "Old JS (no OWL)"

        if ver_int >= 15:
            assets_note = "Required in manifest"
        elif ver_int == 14:
            assets_note = "Optional (newly added)"
        else:
            assets_note = "Not available"

        ver_block = (
            "╔══════════════════════════════════════════╗\n"
            "║  ACTIVE VERSION: ODOO " + version + "\n"
            "║  Answer ONLY for Odoo " + version + ". Do NOT give\n"
            "║  code for other versions unless asked.\n"
            "╚══════════════════════════════════════════╝\n\n"
            "RULES FOR ODOO " + version + ":\n"
            "• List view tag:    " + list_tag + "..." + close_tag + "\n"
            "• Conditional attrs: " + attrs_note + "\n"
            "• view_mode:        " + view_mode + "\n"
            "• Chatter:          " + chatter_tag + "\n"
            "• Python:           " + python_req + "\n"
            "• JavaScript:       " + owl_note + "\n"
            "• Assets key:       " + assets_note + "\n\n"
            "START every answer with: 'In Odoo " + version + ":'"
        )
    else:
        ver_block = (
            "VERSION: All versions (13-19)\n"
            "Specify the version for each code example.\n"
            "Highlight differences between versions."
        )

    # Odoo connection status
    if odoo_connected and odoo_url:
        odoo_block = (
            "LIVE ODOO INSTANCE: CONNECTED\n"
            "URL: " + odoo_url + "\n"
            "Database: " + odoo_db + "\n"
            "You CAN perform real Odoo actions.\n"
            "To run an action, output this exact block:\n"
            "```odoo_action\n"
            "{\"model\": \"res.partner\", \"method\": \"search_read\","
            " \"args\": [[]], \"kwargs\": {\"fields\": [\"name\"], \"limit\": 5}}\n"
            "```"
        )
    else:
        odoo_block = "LIVE ODOO INSTANCE: Not connected."

    return (
        "You are OdooAI — the most precise Odoo AI assistant for versions 13-19.\n\n"
        + ver_block + "\n\n"
        + odoo_block + "\n\n"
        "KNOWLEDGE: Sales, Purchase, Inventory, Accounting, CRM, HR, Manufacturing,\n"
        "Website, eCommerce, POS, ORM, Views, Controllers, QWeb, Wizards, Reports,\n"
        "Security, Cron, XML-RPC API, OCA modules, Installation, Migration.\n\n"
        "WHEN USER ASKS TO CREATE/GENERATE A MODULE:\n"
        "1. Generate ALL files: __manifest__.py, models/*.py, views/*.xml,\n"
        "   security/ir.model.access.csv, data/*.xml, README.md\n"
        "2. Use CORRECT syntax for the requested version\n"
        "3. Make code 100% complete — never truncate\n"
        "4. After generating, say: [MODULE_ZIP_READY] so the UI can offer download\n\n"
        "RULES:\n"
        "1. Use [RETRIEVED DOCS] as primary source\n"
        "2. NEVER mix versions — Odoo 16 gets tree/attrs, Odoo 17 gets list/inline\n"
        "3. Complete working code always — never say 'add more code here'\n"
        "4. max_tokens is 8000 — use all of it if needed for complete code\n"
    )


# ── CONTEXT SEARCH ───────────────────────────────────────────────────────────
async def get_context(message: str, version: str) -> str:
    results = search_knowledge(message, version, limit=5)
    if not results:
        results = search_knowledge(message, "all", limit=4)
    if not results:
        return ""
    parts = ["[RETRIEVED DOCS — Primary source, use these first]"]
    for i, item in enumerate(results, 1):
        ver = item.get("version", "all")
        label = "Odoo " + ver if ver != "all" else "All Versions"
        parts.append(
            "\n--- Doc " + str(i) + ": " + item["title"] + " (" + label + ") ---\n"
            + item["text"][:600]
        )
    return "\n".join(parts)


# ── ODOO XML-RPC ─────────────────────────────────────────────────────────────
def odoo_auth(url, db, username, password):
    import xmlrpc.client as xrc
    try:
        common = xrc.ServerProxy(url + "/xmlrpc/2/common", allow_none=True)
        uid = common.authenticate(db, username, password, {})
        return int(uid) if uid else None
    except Exception as e:
        print("Odoo auth error:", e)
        return None

def odoo_exec(url, db, uid, password, model, method, args=None, kwargs=None):
    import xmlrpc.client as xrc
    try:
        obj = xrc.ServerProxy(url + "/xmlrpc/2/object", allow_none=True)
        return obj.execute_kw(db, uid, password, model, method,
                               args or [], kwargs or {})
    except Exception as e:
        return {"error": str(e)}


# ── MODULE ZIP GENERATOR ─────────────────────────────────────────────────────
def generate_module_zip(module_name: str, version: str,
                        description: str = "", depends: list = None) -> bytes:
    """Generate a complete Odoo module ZIP from scratch."""
    ver = int(version)
    if depends is None:
        depends = ["base", "mail"]
    else:
        depends = list(set(["base", "mail"] + depends))

    mn = module_name.lower().replace(" ", "_").replace("-", "_")
    label = mn.replace("_", " ").title()
    model = mn.replace("_", ".")

    list_tag  = "list" if ver >= 17 else "tree"
    view_mode = "list,form" if ver >= 17 else "tree,form"
    chatter   = "        <chatter/>" if ver >= 17 else (
        '        <div class="oe_chatter">\n'
        '          <field name="message_follower_ids" widget="mail_followers"/>\n'
        '          <field name="activity_ids" widget="mail_activity"/>\n'
        '          <field name="message_ids" widget="mail_thread"/>\n'
        '        </div>'
    )

    if ver >= 17:
        btn_invisible1 = 'invisible="state != \'draft\'"'
        btn_invisible2 = 'invisible="state != \'confirm\'"'
        btn_invisible3 = 'invisible="state == \'draft\'"'
        fld_invisible  = 'invisible="state == \'draft\'"'
        fld_required   = 'required="state == \'confirm\'"'
    else:
        btn_invisible1 = "attrs=\"{'invisible':[('state','!=','draft')]}\""
        btn_invisible2 = "attrs=\"{'invisible':[('state','!=','confirm')]}\""
        btn_invisible3 = "attrs=\"{'invisible':[('state','=','draft')]}\""
        fld_invisible  = "attrs=\"{'invisible':[('state','=','draft')]}\""
        fld_required   = "attrs=\"{'required':[('state','=','confirm')]}\""

    assets_block = ""
    if ver >= 14:
        assets_block = "\n    'assets': {\n        'web.assets_backend': [],\n    },"

    depends_str = str(depends)

    files = {}

    # __manifest__.py
    files["__manifest__.py"] = (
        "{\n"
        "    'name': '" + label + "',\n"
        "    'version': '" + version + ".0.1.0.0',\n"
        "    'category': 'Custom',\n"
        "    'summary': '" + (description or label + " module") + "',\n"
        "    'author': 'My Company',\n"
        "    'license': 'LGPL-3',\n"
        "    'depends': " + depends_str + ",\n"
        "    'data': [\n"
        "        'security/ir.model.access.csv',\n"
        "        'data/ir_sequence.xml',\n"
        "        'views/" + mn + "_views.xml',\n"
        "    ]," + assets_block + "\n"
        "    'installable': True,\n"
        "    'auto_install': False,\n"
        "    'application': False,\n"
        "}\n"
    )

    # __init__.py
    files["__init__.py"] = "from . import models\n"

    # models/__init__.py
    files["models/__init__.py"] = "from . import " + mn + "\n"

    # models/mn.py
    class_name = label.replace(" ", "")
    mname_dot = model.replace(".", "_")

    files["models/" + mn + ".py"] = (
        "from odoo import models, fields, api\n"
        "from odoo.exceptions import UserError, ValidationError\n\n\n"
        "class " + class_name + "(models.Model):\n"
        "    _name = '" + model + "'\n"
        "    _description = '" + label + "'\n"
        "    _inherit = ['mail.thread', 'mail.activity.mixin']\n"
        "    _order = 'date desc, name'\n\n"
        "    name = fields.Char('Name', required=True, tracking=True,\n"
        "                       default=lambda self: '/')\n"
        "    ref = fields.Char('Reference', copy=False, readonly=True)\n"
        "    state = fields.Selection([\n"
        "        ('draft', 'Draft'),\n"
        "        ('confirm', 'Confirmed'),\n"
        "        ('done', 'Done'),\n"
        "        ('cancel', 'Cancelled'),\n"
        "    ], string='State', default='draft', tracking=True)\n"
        "    partner_id = fields.Many2one(\n"
        "        'res.partner', 'Customer', tracking=True,\n"
        "        domain=[('customer_rank', '>', 0)]\n"
        "    )\n"
        "    user_id = fields.Many2one(\n"
        "        'res.users', 'Responsible',\n"
        "        default=lambda self: self.env.user\n"
        "    )\n"
        "    company_id = fields.Many2one(\n"
        "        'res.company', 'Company',\n"
        "        default=lambda self: self.env.company\n"
        "    )\n"
        "    date = fields.Date('Date', default=fields.Date.today)\n"
        "    date_deadline = fields.Date('Deadline')\n"
        "    amount = fields.Float('Amount', digits=(16, 2))\n"
        "    note = fields.Html('Notes')\n"
        "    active = fields.Boolean('Active', default=True)\n"
        "    priority = fields.Selection(\n"
        "        [('0', 'Normal'), ('1', 'Urgent')], default='0'\n"
        "    )\n"
        "    tag_ids = fields.Many2many(\n"
        "        'res.partner.category', string='Tags'\n"
        "    )\n"
        "    line_ids = fields.One2many(\n"
        "        '" + model + ".line', 'parent_id', 'Lines'\n"
        "    )\n"
        "    total = fields.Float(\n"
        "        'Total', compute='_compute_total', store=True\n"
        "    )\n\n"
        "    @api.depends('line_ids.subtotal')\n"
        "    def _compute_total(self):\n"
        "        for rec in self:\n"
        "            rec.total = sum(rec.line_ids.mapped('subtotal'))\n\n"
        "    @api.onchange('partner_id')\n"
        "    def _onchange_partner(self):\n"
        "        if self.partner_id:\n"
        "            self.name = 'Order for ' + self.partner_id.name\n\n"
        "    @api.constrains('amount')\n"
        "    def _check_amount(self):\n"
        "        for rec in self:\n"
        "            if rec.amount < 0:\n"
        "                raise ValidationError('Amount cannot be negative!')\n\n"
        "    @api.model_create_multi\n"
        "    def create(self, vals_list):\n"
        "        for vals in vals_list:\n"
        "            if not vals.get('ref') or vals['ref'] == '/':\n"
        "                vals['ref'] = (\n"
        "                    self.env['ir.sequence'].next_by_code('" + model + "')\n"
        "                    or '/'\n"
        "                )\n"
        "        return super().create(vals_list)\n\n"
        "    def action_confirm(self):\n"
        "        for rec in self:\n"
        "            if not rec.partner_id:\n"
        "                raise UserError('Please select a customer!')\n"
        "            rec.state = 'confirm'\n"
        "            rec.message_post(body='Record confirmed.')\n\n"
        "    def action_done(self):\n"
        "        self.write({'state': 'done'})\n\n"
        "    def action_cancel(self):\n"
        "        self.write({'state': 'cancel'})\n\n"
        "    def action_reset_draft(self):\n"
        "        self.write({'state': 'draft'})\n\n\n"
        "class " + class_name + "Line(models.Model):\n"
        "    _name = '" + model + ".line'\n"
        "    _description = '" + label + " Line'\n"
        "    _order = 'sequence, id'\n\n"
        "    parent_id = fields.Many2one(\n"
        "        '" + model + "', 'Parent', required=True, ondelete='cascade'\n"
        "    )\n"
        "    sequence = fields.Integer('Sequence', default=10)\n"
        "    product_id = fields.Many2one('product.product', 'Product')\n"
        "    name = fields.Char('Description', required=True)\n"
        "    qty = fields.Float('Quantity', default=1.0)\n"
        "    price_unit = fields.Float('Unit Price')\n"
        "    subtotal = fields.Float(\n"
        "        'Subtotal', compute='_compute_subtotal', store=True\n"
        "    )\n\n"
        "    @api.depends('qty', 'price_unit')\n"
        "    def _compute_subtotal(self):\n"
        "        for line in self:\n"
        "            line.subtotal = line.qty * line.price_unit\n\n"
        "    @api.onchange('product_id')\n"
        "    def _onchange_product(self):\n"
        "        if self.product_id:\n"
        "            self.name = self.product_id.name\n"
        "            self.price_unit = self.product_id.lst_price\n"
    )

    # views
    files["views/" + mn + "_views.xml"] = (
        '<?xml version="1.0" encoding="utf-8"?>\n'
        "<odoo>\n\n"
        "  <!-- " + list_tag.upper() + " VIEW — Odoo " + version + " uses <" + list_tag + "> -->\n"
        '  <record id="view_' + mn + '_' + list_tag + '" model="ir.ui.view">\n'
        '    <field name="name">' + model + '.' + list_tag + '</field>\n'
        '    <field name="model">' + model + '</field>\n'
        '    <field name="arch" type="xml">\n'
        "      <" + list_tag + ' string="' + label + '" multi_edit="1"\n'
        '         decoration-danger="state==\'draft\'"\n'
        '         decoration-warning="state==\'confirm\'"\n'
        '         decoration-success="state==\'done\'"\n'
        '         decoration-muted="state==\'cancel\'">\n'
        '        <field name="ref" readonly="1"/>\n'
        '        <field name="name"/>\n'
        '        <field name="partner_id"/>\n'
        '        <field name="date"/>\n'
        '        <field name="amount" sum="Total"/>\n'
        '        <field name="user_id" optional="hide"/>\n'
        '        <field name="state" widget="badge"\n'
        '          decoration-success="state==\'done\'"\n'
        '          decoration-warning="state==\'confirm\'"\n'
        '          decoration-danger="state==\'draft\'"/>\n'
        "      </" + list_tag + ">\n"
        "    </field>\n"
        "  </record>\n\n"
        "  <!-- FORM VIEW -->\n"
        '  <record id="view_' + mn + '_form" model="ir.ui.view">\n'
        '    <field name="name">' + model + '.form</field>\n'
        '    <field name="model">' + model + '</field>\n'
        '    <field name="arch" type="xml">\n'
        '      <form string="' + label + '">\n'
        "        <header>\n"
        '          <button name="action_confirm" string="Confirm"\n'
        '            type="object" class="btn-primary"\n'
        '            ' + btn_invisible1 + '/>\n'
        '          <button name="action_done" string="Mark Done"\n'
        '            type="object" class="btn-success"\n'
        '            ' + btn_invisible2 + '/>\n'
        '          <button name="action_cancel" string="Cancel"\n'
        '            type="object"\n'
        '            ' + btn_invisible3 + '/>\n'
        '          <button name="action_reset_draft" string="Reset"\n'
        '            type="object" invisible="state == \'draft\'"/>\n'
        '          <field name="state" widget="statusbar"\n'
        '            statusbar_visible="draft,confirm,done"/>\n'
        "        </header>\n"
        "        <sheet>\n"
        '          <div class="oe_title">\n'
        '            <h1><field name="name" placeholder="Record Name"/></h1>\n'
        "          </div>\n"
        "          <group>\n"
        '            <group string="General">\n'
        '              <field name="ref" readonly="1"/>\n'
        '              <field name="partner_id"/>\n'
        '              <field name="user_id"/>\n'
        '              <field name="company_id"\n'
        '                groups="base.group_multi_company"/>\n'
        "            </group>\n"
        '            <group string="Details">\n'
        '              <field name="date"/>\n'
        '              <field name="date_deadline"/>\n'
        '              <field name="amount"\n'
        '                ' + fld_invisible + '\n'
        '                ' + fld_required + '/>\n'
        '              <field name="total" readonly="1"/>\n'
        "            </group>\n"
        "          </group>\n"
        "          <notebook>\n"
        '            <page string="Lines" name="lines">\n'
        '              <field name="line_ids">\n'
        '                <' + list_tag + ' editable="bottom">\n'
        '                  <field name="sequence" widget="handle"/>\n'
        '                  <field name="product_id"/>\n'
        '                  <field name="name"/>\n'
        '                  <field name="qty"/>\n'
        '                  <field name="price_unit"/>\n'
        '                  <field name="subtotal" readonly="1"/>\n'
        '                </' + list_tag + '>\n'
        "              </field>\n"
        "            </page>\n"
        '            <page string="Notes" name="notes">\n'
        '              <field name="note" widget="html"\n'
        '                placeholder="Internal notes..."/>\n'
        "            </page>\n"
        "          </notebook>\n"
        "        </sheet>\n"
        + chatter + "\n"
        "      </form>\n"
        "    </field>\n"
        "  </record>\n\n"
        "  <!-- SEARCH VIEW -->\n"
        '  <record id="view_' + mn + '_search" model="ir.ui.view">\n'
        '    <field name="name">' + model + '.search</field>\n'
        '    <field name="model">' + model + '</field>\n'
        '    <field name="arch" type="xml">\n'
        "      <search>\n"
        '        <field name="name"/>\n'
        '        <field name="partner_id"/>\n'
        '        <field name="ref"/>\n'
        "        <separator/>\n"
        '        <filter name="draft" string="Draft"\n'
        "          domain=\"[('state','=','draft')]\"/>\n"
        '        <filter name="confirm" string="Confirmed"\n'
        "          domain=\"[('state','=','confirm')]\"/>\n"
        '        <filter name="done" string="Done"\n'
        "          domain=\"[('state','=','done')]\"/>\n"
        "        <separator/>\n"
        '        <filter name="my_records" string="My Records"\n'
        "          domain=\"[('user_id','=',uid)]\"/>\n"
        '        <group expand="0" string="Group By">\n'
        '          <filter name="by_partner" string="Customer"\n'
        "            context=\"{'group_by':'partner_id'}\"/>\n"
        '          <filter name="by_state" string="State"\n'
        "            context=\"{'group_by':'state'}\"/>\n"
        '          <filter name="by_date" string="Date"\n'
        "            context=\"{'group_by':'date:month'}\"/>\n"
        "        </group>\n"
        "      </search>\n"
        "    </field>\n"
        "  </record>\n\n"
        "  <!-- ACTION -->\n"
        '  <record id="action_' + mn + '" model="ir.actions.act_window">\n'
        '    <field name="name">' + label + '</field>\n'
        '    <field name="res_model">' + model + '</field>\n'
        '    <field name="view_mode">' + view_mode + '</field>\n'
        '    <field name="search_view_id" ref="view_' + mn + '_search"/>\n'
        "    <field name=\"context\">{'search_default_draft': 1}</field>\n"
        "  </record>\n\n"
        "  <!-- MENUS -->\n"
        '  <menuitem id="menu_' + mn + '_root" name="' + label + '"\n'
        '    sequence="90" groups="base.group_user"/>\n'
        '  <menuitem id="menu_' + mn + '" name="' + label + '"\n'
        '    parent="menu_' + mn + '_root"\n'
        '    action="action_' + mn + '" sequence="10"/>\n\n'
        "</odoo>\n"
    )

    # security
    line_dot = (model + ".line").replace(".", "_")
    files["security/ir.model.access.csv"] = (
        "id,name,model_id:id,group_id:id,"
        "perm_read,perm_write,perm_create,perm_unlink\n"
        "access_" + mname_dot + "_user," + model + " user,"
        "model_" + mname_dot + ",base.group_user,1,1,1,0\n"
        "access_" + mname_dot + "_mgr," + model + " manager,"
        "model_" + mname_dot + ",base.group_system,1,1,1,1\n"
        "access_" + line_dot + "_user," + model + ".line,"
        "model_" + line_dot + ",base.group_user,1,1,1,0\n"
    )

    # data/ir_sequence.xml
    files["data/ir_sequence.xml"] = (
        '<?xml version="1.0" encoding="utf-8"?>\n'
        "<odoo>\n"
        '  <data noupdate="1">\n'
        '    <record id="seq_' + mn + '" model="ir.sequence">\n'
        '      <field name="name">' + label + ' Sequence</field>\n'
        "      <field name=\"code\">" + model + "</field>\n"
        '      <field name="prefix">%(year)s/%(month)s/</field>\n'
        '      <field name="padding">4</field>\n'
        "      <field name=\"company_id\" eval=\"False\"/>\n"
        "    </record>\n"
        "  </data>\n"
        "</odoo>\n"
    )

    # README
    tag_note = "<list> (Odoo 17+)" if ver >= 17 else "<tree> (Odoo 13-16)"
    attr_note = "inline invisible= (Odoo 17+)" if ver >= 17 else "attrs= (Odoo 13-16)"

    files["README.md"] = (
        "# " + label + " — Odoo " + version + " Module\n\n"
        "## Description\n"
        + (description or "Custom " + label + " module") + "\n\n"
        "## Installation\n"
        "1. Copy folder to Odoo addons path\n"
        "2. Restart Odoo: `sudo systemctl restart odoo`\n"
        "3. Apps → Update Apps List\n"
        "4. Search '" + label + "' → Install\n\n"
        "## Features\n"
        "- Complete CRUD with status workflow\n"
        "- Chatter (messages + activities)\n"
        "- Multi-company support\n"
        "- List, Form, Search views\n"
        "- Auto-sequence on create\n"
        "- Order lines with subtotal\n\n"
        "## Version Notes\n"
        "- Odoo " + version + " compatible\n"
        "- View tag: " + tag_note + "\n"
        "- Attributes: " + attr_note + "\n"
    )

    # Build ZIP in memory
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        for filepath, content in files.items():
            zf.writestr(mn + "/" + filepath, content)
    buf.seek(0)
    return buf.read()


# ── ROUTES ────────────────────────────────────────────────────────────────────
@app.get("/")
async def root():
    return {
        "name": "OdooAI API", "version": "7.0.0",
        "provider": AI_PROVIDER,
        "knowledge_chunks": len(get_all_knowledge()),
        "status": "running"
    }

@app.get("/health")
async def health():
    return {
        "status": "ok", "provider": AI_PROVIDER,
        "api_key_set": bool(OPENROUTER_API_KEY or ANTHROPIC_API_KEY),
        "knowledge_chunks": len(get_all_knowledge()),
        "timestamp": datetime.utcnow().isoformat()
    }


@app.post("/chat")
async def chat(req: ChatRequest):
    if not OPENROUTER_API_KEY and not ANTHROPIC_API_KEY:
        raise HTTPException(status_code=500,
                            detail="No API key. Add OPENROUTER_API_KEY to .env")

    version = req.version or "all"
    odoo_connected = bool(
        req.odoo_url and req.odoo_db and req.odoo_user and req.odoo_password
    )
    system = build_system_prompt(
        version, odoo_connected,
        req.odoo_url or "", req.odoo_db or ""
    )
    context = await get_context(req.message, version)

    file_part = ""
    if req.file_content and req.file_name:
        file_part = (
            "\n[UPLOADED FILE: " + req.file_name + "]\n"
            + req.file_content[:3000] + "\n"
        )

    if context or file_part:
        user_content = (
            context + file_part
            + "\n\n[QUESTION — Odoo " + version + "]\n" + req.message
        )
    else:
        user_content = "[Odoo " + version + "]\n" + req.message

    messages = list(req.conversation_history or [])[-12:]
    messages.append({"role": "user", "content": user_content})

    if AI_PROVIDER == "openrouter":
        full_msgs = [{"role": "system", "content": system}] + messages
        headers = {
            "Authorization": "Bearer " + OPENROUTER_API_KEY,
            "Content-Type": "application/json",
            "HTTP-Referer": "http://localhost:3000",
            "X-Title": "OdooAI",
        }
        payload = {
            "model": OPENROUTER_MODEL,
            "messages": full_msgs,
            "max_tokens": 8000
        }
        async with httpx.AsyncClient(timeout=90) as http:
            r = await http.post(
                "https://openrouter.ai/api/v1/chat/completions",
                headers=headers, json=payload
            )
            if r.status_code != 200:
                raise HTTPException(
                    status_code=r.status_code,
                    detail="AI error: " + r.text[:500]
                )
            reply = r.json()["choices"][0]["message"]["content"]
    else:
        import anthropic as ant
        client = ant.Anthropic(api_key=ANTHROPIC_API_KEY)
        response = client.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=8000, system=system, messages=messages
        )
        reply = response.content[0].text

    # Handle live Odoo action
    odoo_result = None
    if "```odoo_action" in reply and req.enable_actions and odoo_connected:
        import re
        m = re.search(r"```odoo_action\n(.*?)```", reply, re.DOTALL)
        if m:
            try:
                action = json.loads(m.group(1))
                uid = odoo_auth(req.odoo_url, req.odoo_db,
                                req.odoo_user, req.odoo_password)
                if uid:
                    odoo_result = odoo_exec(
                        req.odoo_url, req.odoo_db, uid, req.odoo_password,
                        action["model"], action["method"],
                        action.get("args", []), action.get("kwargs", {})
                    )
            except Exception as e:
                odoo_result = {"error": str(e)}

    # Auto-detect module generation request
    module_zip_data = None
    module_zip_name = None
    if "[MODULE_ZIP_READY]" in reply or (
        any(kw in req.message.lower() for kw in
            ["create module", "generate module", "make module",
             "create a module", "module banao", "module bnao"])
    ):
        # Try to extract module name from message or reply
        import re as re2
        mn_match = re2.search(
            r"(?:module[_\s]name|called|named?|module)[:\s]+([a-z][a-z0-9_]+)",
            req.message.lower()
        )
        if mn_match:
            mn = mn_match.group(1)
        else:
            mn = "my_custom_module"

        try:
            zip_bytes = generate_module_zip(mn, version if version != "all" else "17")
            module_zip_name = mn + "_odoo" + (version if version != "all" else "17") + ".zip"
            # save to temp
            zip_path = TEMP_DIR / module_zip_name
            zip_path.write_bytes(zip_bytes)
            module_zip_data = "/download-module/" + module_zip_name
        except Exception as e:
            print("Module gen error:", e)

    return {
        "reply": reply.replace("[MODULE_ZIP_READY]", ""),
        "odoo_result": odoo_result,
        "context_used": bool(context),
        "version_filter": version,
        "odoo_connected": odoo_connected,
        "provider": AI_PROVIDER,
        "module_zip_url": module_zip_data,
        "module_zip_name": module_zip_name,
    }


@app.post("/chat/stream")
async def chat_stream(req: ChatRequest):
    if not OPENROUTER_API_KEY and not ANTHROPIC_API_KEY:
        async def err():
            yield "data: " + json.dumps({"type": "error", "content": "No API key in .env"}) + "\n\n"
        return StreamingResponse(err(), media_type="text/event-stream")

    version = req.version or "all"
    odoo_connected = bool(
        req.odoo_url and req.odoo_db and req.odoo_user and req.odoo_password
    )
    system = build_system_prompt(
        version, odoo_connected,
        req.odoo_url or "", req.odoo_db or ""
    )
    context = await get_context(req.message, version)

    file_part = ""
    if req.file_content and req.file_name:
        file_part = (
            "\n[UPLOADED FILE: " + req.file_name + "]\n"
            + req.file_content[:3000] + "\n"
        )

    if context or file_part:
        user_content = (
            context + file_part
            + "\n\n[QUESTION — Odoo " + version + "]\n" + req.message
        )
    else:
        user_content = "[Odoo " + version + "]\n" + req.message

    messages = list(req.conversation_history or [])[-12:]
    messages.append({"role": "user", "content": user_content})

    stream_id = req.stream_id or str(uuid.uuid4())
    active_streams[stream_id] = True

    async def gen_openrouter():
        full_msgs = [{"role": "system", "content": system}] + messages
        headers = {
            "Authorization": "Bearer " + OPENROUTER_API_KEY,
            "Content-Type": "application/json",
            "HTTP-Referer": "http://localhost:3000",
            "X-Title": "OdooAI",
        }
        payload = {
            "model": OPENROUTER_MODEL,
            "messages": full_msgs,
            "max_tokens": 8000,
            "stream": True
        }
        try:
            async with httpx.AsyncClient(timeout=180) as http:
                async with http.stream(
                    "POST",
                    "https://openrouter.ai/api/v1/chat/completions",
                    headers=headers, json=payload
                ) as r:
                    async for line in r.aiter_lines():
                        if not active_streams.get(stream_id, True):
                            yield "data: " + json.dumps({"type": "stopped"}) + "\n\n"
                            break
                        if line.startswith("data: "):
                            ds = line[6:]
                            if ds == "[DONE]":
                                yield "data: " + json.dumps({"type": "done"}) + "\n\n"
                                break
                            try:
                                d = json.loads(ds)
                                delta = d["choices"][0]["delta"].get("content", "")
                                if delta:
                                    yield "data: " + json.dumps(
                                        {"type": "text", "content": delta}
                                    ) + "\n\n"
                            except Exception:
                                pass
        except Exception as e:
            yield "data: " + json.dumps({"type": "error", "content": str(e)}) + "\n\n"
        finally:
            active_streams.pop(stream_id, None)

    async def gen_anthropic():
        import anthropic as ant
        client = ant.Anthropic(api_key=ANTHROPIC_API_KEY)
        try:
            with client.messages.stream(
                model="claude-sonnet-4-20250514",
                max_tokens=8000, system=system, messages=messages
            ) as stream:
                for text in stream.text_stream:
                    if not active_streams.get(stream_id, True):
                        yield "data: " + json.dumps({"type": "stopped"}) + "\n\n"
                        break
                    yield "data: " + json.dumps({"type": "text", "content": text}) + "\n\n"
            yield "data: " + json.dumps({"type": "done"}) + "\n\n"
        except Exception as e:
            yield "data: " + json.dumps({"type": "error", "content": str(e)}) + "\n\n"
        finally:
            active_streams.pop(stream_id, None)

    gen = gen_openrouter() if AI_PROVIDER == "openrouter" else gen_anthropic()
    return StreamingResponse(
        gen, media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "X-Accel-Buffering": "no",
            "X-Stream-ID": stream_id
        }
    )


@app.post("/chat/stop")
async def stop_stream(req: StopRequest):
    active_streams[req.stream_id] = False
    return {"stopped": True, "stream_id": req.stream_id}


@app.post("/generate-module")
async def generate_module_endpoint(body: dict):
    mn      = body.get("module_name", "my_module")
    version = body.get("version", "17")
    desc    = body.get("description", "")
    depends = body.get("depends", [])

    try:
        zip_bytes = generate_module_zip(mn, version, desc, depends)
        clean = mn.lower().replace(" ", "_")
        filename = clean + "_odoo" + version + ".zip"
        return StreamingResponse(
            io.BytesIO(zip_bytes),
            media_type="application/zip",
            headers={
                "Content-Disposition": "attachment; filename=" + filename,
                "Content-Length": str(len(zip_bytes)),
            }
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/download-module/{filename}")
async def download_module(filename: str):
    path = TEMP_DIR / filename
    if path.exists():
        return FileResponse(
            str(path), media_type="application/zip",
            filename=filename,
            headers={"Content-Disposition": "attachment; filename=" + filename}
        )
    raise HTTPException(status_code=404, detail="File not found")


@app.post("/generate-zip")
async def generate_zip_from_code(body: dict):
    files    = body.get("files", {})
    zip_name = body.get("zip_name", "odooai_code.zip")
    if not files:
        raise HTTPException(status_code=400, detail="No files provided")
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        for filepath, content in files.items():
            zf.writestr(filepath, content)
    buf.seek(0)
    return StreamingResponse(
        buf, media_type="application/zip",
        headers={"Content-Disposition": "attachment; filename=" + zip_name}
    )


@app.post("/upload-file")
async def upload_file(file: UploadFile = File(...)):
    content = await file.read()
    filename = file.filename or "unknown"
    ext = filename.rsplit(".", 1)[-1].lower() if "." in filename else ""
    if ext in ("py", "xml", "csv", "txt", "md", "json", "js", "scss", "html", "rst"):
        try:
            text = content.decode("utf-8")
        except Exception:
            text = content.decode("latin-1")
        return {"filename": filename, "content": text[:8000], "type": "text"}
    elif ext == "zip":
        items = []
        try:
            with zipfile.ZipFile(io.BytesIO(content)) as zf:
                for name in zf.namelist()[:20]:
                    if not name.endswith("/"):
                        try:
                            txt = zf.read(name).decode("utf-8")[:2000]
                            items.append("=== " + name + " ===\n" + txt)
                        except Exception:
                            pass
        except Exception:
            pass
        return {"filename": filename, "content": "\n\n".join(items)[:8000], "type": "zip"}
    else:
        return {"filename": filename, "content": "[Binary file: " + filename + "]", "type": "binary"}


@app.post("/odoo/test-connection")
async def test_odoo(req: OdooActionRequest):
    uid = odoo_auth(req.odoo_url, req.db, req.username, req.password)
    if uid:
        info = {}
        try:
            info["partner_count"] = odoo_exec(
                req.odoo_url, req.db, uid, req.password,
                "res.partner", "search_count", [[]]
            )
            info["sale_count"] = odoo_exec(
                req.odoo_url, req.db, uid, req.password,
                "sale.order", "search_count", [[]]
            )
        except Exception:
            pass
        return {"connected": True, "uid": uid, "url": req.odoo_url, "info": info}
    raise HTTPException(
        status_code=401,
        detail="Cannot connect. Check URL (include https://), DB name, username, password."
    )

@app.post("/odoo/action")
async def odoo_action(req: OdooActionRequest):
    uid = odoo_auth(req.odoo_url, req.db, req.username, req.password)
    if not uid:
        raise HTTPException(status_code=401, detail="Odoo authentication failed")
    result = odoo_exec(
        req.odoo_url, req.db, uid, req.password,
        req.model, req.method, req.args, req.kwargs
    )
    return {"result": result, "uid": uid}

@app.get("/versions")
async def versions():
    return {"versions": ["13", "14", "15", "16", "17", "18", "19"]}

@app.get("/knowledge")
async def knowledge():
    items = get_all_knowledge()
    return {
        "total": len(items),
        "topics": [{"title": i["title"], "version": i["version"]} for i in items]
    }

@app.get("/stats")
async def stats():
    return {
        "builtin_knowledge_chunks": len(get_all_knowledge()),
        "provider": AI_PROVIDER,
        "model": OPENROUTER_MODEL if AI_PROVIDER == "openrouter" else "claude-sonnet-4-20250514"
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000, reload=True)
