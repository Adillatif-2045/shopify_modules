# 🤖 OdooRAG — AI Assistant for Odoo 13–19

A full-stack RAG (Retrieval-Augmented Generation) web application that lets you chat with an AI that knows everything about Odoo. It can also connect to your live Odoo instance and perform actions directly.

---

## 🏗️ Architecture

```
Browser (Chat UI)
      │
      ▼
Frontend (HTML/JS) ──► Backend (FastAPI)
                              │
                    ┌─────────┴──────────┐
                    ▼                    ▼
               Qdrant DB          Anthropic API
           (Vector search)      (Claude claude-sonnet-4-20250514)
                    ▲
               Scraper
          (Odoo Docs + OCA)
                              │
                    ┌─────────┴──────────┐
                    ▼                    ▼
            Odoo XML-RPC          GitHub API
          (Live instance)      (Code indexing)
```

---

## 🚀 Quick Start (Beginners)

### Step 1: Install Required Tools

**Docker Desktop** (the only thing you really need):
- Windows/Mac: https://www.docker.com/products/docker-desktop/
- Linux: `curl -fsSL https://get.docker.com | sh`

### Step 2: Get Your API Key

1. Go to https://console.anthropic.com
2. Sign up / Log in
3. Click "API Keys" → "Create Key"
4. Copy the key (starts with `sk-ant-...`)

### Step 3: Setup the Project

```bash
# 1. Unzip the project
unzip odoo-rag.zip
cd odoo-rag

# 2. Create your .env file
cp .env.example .env

# 3. Open .env in any text editor and paste your API key:
#    ANTHROPIC_API_KEY=sk-ant-YOUR_KEY_HERE
```

### Step 4: Start Everything

**On Mac/Linux:**
```bash
bash scripts/start.sh
```

**On Windows:**
```
Double-click scripts/start.bat
```

**Or manually:**
```bash
cd docker
docker compose up -d
```

### Step 5: Open the App

Go to: **http://localhost:3000**

That's it! 🎉

---

## 📚 Index Odoo Documentation (Recommended)

After starting, run the scraper to index Odoo docs into the vector DB:

```bash
cd docker

# Index specific versions (faster)
docker compose --profile scrape run scraper python scraper.py 17 18

# Index ALL versions 13-19 (takes 30-60 min)
docker compose --profile scrape run scraper python scraper.py
```

**Without indexing**, the AI still works but answers from its training data only (no retrieved docs).

---

## 🔌 Connect to Your Odoo Instance

In the left sidebar of the chat:
1. Enter your Odoo URL (e.g. `https://mycompany.odoo.com`)
2. Enter Database name
3. Enter username and password
4. Click "Connect to Odoo"
5. Enable "Live actions" toggle to allow the AI to query/modify data

### What the AI can do with live Odoo:
- Read partners, invoices, products, etc.
- Create/update records
- Run reports
- Check stock, sales, HR data
- Execute any model method

### Example prompts with live Odoo:
- "Show me the top 10 customers by sales"
- "Create a new partner named John Doe with email john@example.com"
- "What's the current stock of product REF001?"
- "List all unpaid invoices from this month"

---

## 💬 How to Use the Chat

### Version Filtering
Select an Odoo version from the dropdown (top right) to filter doc search to that version.

### Example Questions
```
General:
- "How do I install Odoo 18 on Ubuntu?"
- "What's new in Odoo 17 compared to 16?"
- "Explain Odoo's multi-company setup"

Development:
- "How do I create a custom module in Odoo 17?"
- "Write a Python model for a custom helpdesk ticket"
- "How do I add a field to res.partner without modifying core?"
- "Show me how to write a QWeb report"

OCA Modules:
- "What does the account-financial-reporting OCA module do?"
- "How do I install OCA modules?"

API:
- "How do I connect to Odoo via XML-RPC in Python?"
- "Show me REST API examples for Odoo 17"
```

---

## 🗂️ Project Structure

```
odoo-rag/
├── backend/
│   ├── main.py          # FastAPI app — chat, RAG, Odoo actions
│   ├── requirements.txt
│   └── Dockerfile
├── frontend/
│   └── index.html       # Full chat UI (single file)
├── scraper/
│   ├── scraper.py       # Docs scraper + Qdrant indexer
│   ├── requirements.txt
│   └── Dockerfile
├── docker/
│   ├── docker-compose.yml
│   └── nginx.conf
├── scripts/
│   ├── start.sh         # Linux/Mac startup
│   └── start.bat        # Windows startup
└── .env.example
```

---

## 🔧 Configuration

All config is in `.env`:

```env
# Required
ANTHROPIC_API_KEY=sk-ant-...

# Optional: use Qdrant Cloud instead of local
QDRANT_URL=https://xyz.qdrant.io
QDRANT_API_KEY=your-qdrant-key
```

---

## 🌐 API Reference

The backend runs at `http://localhost:8000`. Full docs at `/docs`.

### POST /chat
```json
{
  "message": "How do I create a custom module?",
  "version": "17",
  "odoo_url": "https://myodoo.com",
  "odoo_db": "mydb",
  "odoo_user": "admin",
  "odoo_password": "secret",
  "enable_actions": true,
  "conversation_history": []
}
```

### POST /chat/stream
Same as above but returns Server-Sent Events for streaming.

### POST /odoo/action
```json
{
  "odoo_url": "https://myodoo.com",
  "db": "mydb",
  "username": "admin",
  "password": "secret",
  "model": "res.partner",
  "method": "search_read",
  "args": [[["customer_rank", ">", 0]]],
  "kwargs": {"fields": ["name", "email"], "limit": 5}
}
```

---

## 🔄 Upgrade to Production Embeddings

The default embedding is a deterministic mock (for demo). For production:

1. **Voyage AI** (recommended):
   ```python
   # In scraper/scraper.py, replace get_embedding():
   import voyageai
   vo = voyageai.Client(api_key="your-voyage-key")
   def get_embedding(text):
       return vo.embed([text], model="voyage-3").embeddings[0]
   ```

2. **OpenAI embeddings**:
   ```python
   from openai import OpenAI
   openai_client = OpenAI(api_key="sk-...")
   def get_embedding(text):
       return openai_client.embeddings.create(
           input=text, model="text-embedding-3-small"
       ).data[0].embedding
   ```

Also update `EMBED_DIM` to match (voyage-3: 1024, text-embedding-3-small: 1536).

---

## 🛑 Common Issues

| Problem | Solution |
|---------|----------|
| "Backend not reachable" | Check `docker ps` — is `odoorag-backend` running? |
| "No Odoo connected" | Fill sidebar fields and click Connect |
| Slow responses | Normal first time — Claude is thinking |
| Port 3000 in use | Change port in docker-compose.yml |
| Qdrant empty | Run the scraper first |
| API key error | Check .env file has correct key |

---

## 📦 Tech Stack

| Component | Technology |
|-----------|-----------|
| AI Model | Claude claude-sonnet-4-20250514 (Anthropic) |
| Vector DB | Qdrant |
| Backend | Python FastAPI |
| Frontend | Vanilla HTML/CSS/JS |
| Scraper | httpx + BeautifulSoup |
| Odoo API | XML-RPC |
| Container | Docker + Nginx |

---

## 🤝 Extending OdooRAG

### Add GitHub Code Indexing
```python
# In scraper.py — add GitHub search
GITHUB_TOKEN = os.getenv("GITHUB_TOKEN")
# Search OCA repos: https://api.github.com/search/code?q=org:OCA+language:python
```

### Add More OCA Modules
Edit `oca_repos` list in `scraper.py` to add any OCA repository name.

### Deploy to Cloud
1. Build images: `docker compose build`
2. Push to Docker Hub or AWS ECR
3. Deploy on any VPS, AWS ECS, or Render.com
4. Set environment variables in cloud provider
