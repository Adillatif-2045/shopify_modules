@echo off
title OdooRAG Quick Start

echo.
echo ╔══════════════════════════════════════════╗
echo ║         OdooRAG — Quick Start            ║
echo ╚══════════════════════════════════════════╝
echo.

if not exist .env (
  echo ⚠️  No .env file found. Creating from template...
  copy .env.example .env
  echo ✏️  Edit .env and add your ANTHROPIC_API_KEY, then run this script again.
  pause
  exit /b 1
)

where docker >nul 2>&1
if errorlevel 1 (
  echo ❌ Docker not found. Install from https://docker.com
  pause
  exit /b 1
)

echo ✅ Docker found
echo.
echo 🚀 Starting services...

cd docker
docker compose up -d qdrant backend frontend

echo.
echo ⏳ Waiting 10 seconds for startup...
timeout /t 10 /nobreak >nul

echo.
echo ══════════════════════════════════════════
echo 🌐 Frontend:  http://localhost:3000
echo 🔧 API Docs:  http://localhost:8000/docs
echo 📊 Qdrant UI: http://localhost:6333/dashboard
echo ══════════════════════════════════════════
echo.
echo 📚 To index docs: docker compose --profile scrape up scraper
echo 🛑 To stop:       docker compose down
echo.
pause
