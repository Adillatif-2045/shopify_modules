#!/bin/bash
# OdooRAG Quick Start — run from the odoo-rag/ project root
set -e

echo ""
echo "╔══════════════════════════════════════════╗"
echo "║         OdooRAG — Quick Start            ║"
echo "╚══════════════════════════════════════════╝"
echo ""

# Always work from the project root
PROJECT_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$PROJECT_ROOT"
echo "📁 Project root: $PROJECT_ROOT"

# Check .env
if [ ! -f .env ]; then
  echo "⚠️  No .env file found. Creating from template..."
  cp .env.example .env
  echo ""
  echo "✏️  Please edit .env and add your ANTHROPIC_API_KEY:"
  echo "    nano .env"
  echo "    Then run this script again."
  exit 1
fi

# Check API key placeholder not still there
if grep -q "YOUR_KEY_HERE" .env; then
  echo "❌ You haven't set your ANTHROPIC_API_KEY in .env yet!"
  echo "   Run:  nano .env"
  exit 1
fi

echo "✅ .env found with API key"

# Check docker running
if ! command -v docker &> /dev/null; then
  echo "❌ Docker not found. Install with:"
  echo "   sudo apt install docker.io docker-compose-plugin -y"
  exit 1
fi

if ! docker info &>/dev/null; then
  echo "❌ Docker daemon not running. Fix with:"
  echo "   sudo systemctl start docker"
  echo "   sudo usermod -aG docker \$USER   (then log out & back in)"
  exit 1
fi

echo "✅ Docker is running"
echo ""
echo "🚀 Starting Qdrant + Backend + Frontend..."

cd docker
docker compose down --remove-orphans 2>/dev/null || true
docker compose up -d --build qdrant backend frontend

echo ""
echo "⏳ Waiting 15 seconds for services to start..."
sleep 15

if curl -sf http://localhost:8000/health > /dev/null 2>&1; then
  echo "✅ Backend API is ready!"
else
  echo "⚠️  Backend may still be building. Check: docker logs odoorag-backend"
fi

echo ""
echo "══════════════════════════════════════════════"
echo "🌐 Chat App:   http://localhost:3000"
echo "🔧 API Docs:   http://localhost:8000/docs"
echo "📊 Qdrant UI:  http://localhost:6333/dashboard"
echo "══════════════════════════════════════════════"
echo ""
echo "📚 Index Odoo docs (run once):"
echo "   cd docker && docker compose --profile scrape run scraper python scraper.py 17 18"
echo ""
echo "🛑 Stop: cd docker && docker compose down"
